<?php
// Session configuration
if (session_status() === PHP_SESSION_NONE) {
    session_start([
        'cookie_lifetime' => 86400, // 24 hours
        'cookie_secure' => isset($_SERVER['HTTPS']),
        'cookie_httponly' => true,
        'cookie_samesite' => 'Strict',
        'use_strict_mode' => true,
        'sid_length' => 128,
        'sid_bits_per_character' => 6
    ]);
}

function requireAuth() {
    if (!isset($_SESSION['user_id'])) {
        http_response_code(401);
        echo json_encode(['error' => 'Authentication required']);
        exit;
    }
}

function checkSessionExpiry() {
    if (isset($_SESSION['last_activity'])) {
        $timeout = 3600; // 1 hour
        if (time() - $_SESSION['last_activity'] > $timeout) {
            session_unset();
            session_destroy();
            http_response_code(401);
            echo json_encode(['error' => 'Session expired']);
            exit;
        }
    }
    $_SESSION['last_activity'] = time();
}

function regenerateSession() {
    session_regenerate_id(true);
}

function getSessionData() {
    return [
        'user_id' => $_SESSION['user_id'] ?? null,
        'user_email' => $_SESSION['user_email'] ?? null,
        'user_name' => $_SESSION['user_name'] ?? null,
        'subscription_plan' => $_SESSION['subscription_plan'] ?? null,
        'subscription_status' => $_SESSION['subscription_status'] ?? null
    ];
}
?>
