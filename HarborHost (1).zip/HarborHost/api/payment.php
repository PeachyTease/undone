<?php
session_start();
require_once '../config/database.php';
require_once '../config/stripe.php';

// Include Stripe PHP SDK (install via Composer or download)
// For GoDaddy, you may need to manually include the Stripe library
require_once '../vendor/autoload.php'; // If using Composer
// OR include Stripe files manually if not using Composer

\Stripe\Stripe::setApiKey(StripeConfig::getSecretKey());

header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['error' => 'Method not allowed']);
    exit;
}

try {
    // Check if user is logged in
    if (!isset($_SESSION['user_id'])) {
        http_response_code(401);
        echo json_encode(['error' => 'User not authenticated']);
        exit;
    }

    $input = json_decode(file_get_contents('php://input'), true);
    
    $action = $input['action'] ?? '';
    
    switch ($action) {
        case 'create_subscription':
            createSubscription($input);
            break;
        case 'cancel_subscription':
            cancelSubscription($input);
            break;
        case 'update_payment_method':
            updatePaymentMethod($input);
            break;
        default:
            http_response_code(400);
            echo json_encode(['error' => 'Invalid action']);
    }

} catch (Exception $e) {
    error_log("Payment API error: " . $e->getMessage());
    http_response_code(500);
    echo json_encode(['error' => 'Payment processing failed']);
}

function createSubscription($input) {
    if (!isset($input['payment_method_id']) || !isset($input['plan'])) {
        http_response_code(400);
        echo json_encode(['error' => 'Payment method and plan are required']);
        return;
    }

    $userId = $_SESSION['user_id'];
    $planId = $input['plan'];
    $paymentMethodId = $input['payment_method_id'];
    
    $priceIds = StripeConfig::getPriceIds();
    
    if (!isset($priceIds[$planId])) {
        http_response_code(400);
        echo json_encode(['error' => 'Invalid plan']);
        return;
    }

    try {
        $database = new Database();
        $db = $database->getConnection();

        // Get user details
        $userQuery = "SELECT email, first_name, last_name, stripe_customer_id FROM users WHERE id = :user_id";
        $userStmt = $db->prepare($userQuery);
        $userStmt->bindParam(':user_id', $userId);
        $userStmt->execute();
        $user = $userStmt->fetch();

        if (!$user) {
            http_response_code(404);
            echo json_encode(['error' => 'User not found']);
            return;
        }

        // Create or retrieve Stripe customer
        $customerId = $user['stripe_customer_id'];
        
        if (!$customerId) {
            $customer = \Stripe\Customer::create([
                'email' => $user['email'],
                'name' => $user['first_name'] . ' ' . $user['last_name'],
                'payment_method' => $paymentMethodId,
                'invoice_settings' => [
                    'default_payment_method' => $paymentMethodId,
                ],
            ]);
            $customerId = $customer->id;

            // Update user with customer ID
            $updateCustomerQuery = "UPDATE users SET stripe_customer_id = :customer_id WHERE id = :user_id";
            $updateCustomerStmt = $db->prepare($updateCustomerQuery);
            $updateCustomerStmt->bindParam(':customer_id', $customerId);
            $updateCustomerStmt->bindParam(':user_id', $userId);
            $updateCustomerStmt->execute();
        } else {
            // Attach payment method to existing customer
            $paymentMethod = \Stripe\PaymentMethod::retrieve($paymentMethodId);
            $paymentMethod->attach(['customer' => $customerId]);
        }

        // Create subscription with trial period
        $subscription = \Stripe\Subscription::create([
            'customer' => $customerId,
            'items' => [
                ['price' => $priceIds[$planId]],
            ],
            'trial_period_days' => 7,
            'expand' => ['latest_invoice.payment_intent'],
        ]);

        // Update user subscription info
        $updateSubQuery = "UPDATE users SET 
                          subscription_plan = :plan,
                          subscription_status = :status,
                          stripe_subscription_id = :subscription_id,
                          trial_ends_at = DATE_ADD(NOW(), INTERVAL 7 DAY)
                          WHERE id = :user_id";
        $updateSubStmt = $db->prepare($updateSubQuery);
        $updateSubStmt->bindParam(':plan', $planId);
        $updateSubStmt->bindParam(':status', $subscription->status);
        $updateSubStmt->bindParam(':subscription_id', $subscription->id);
        $updateSubStmt->bindParam(':user_id', $userId);
        $updateSubStmt->execute();

        // Update session
        $_SESSION['subscription_plan'] = $planId;
        $_SESSION['subscription_status'] = $subscription->status;

        echo json_encode([
            'success' => true,
            'subscription' => [
                'id' => $subscription->id,
                'status' => $subscription->status,
                'plan' => $planId,
                'trial_end' => $subscription->trial_end
            ]
        ]);

    } catch (\Stripe\Exception\CardException $e) {
        http_response_code(402);
        echo json_encode(['error' => $e->getError()->message]);
    }
}

function cancelSubscription($input) {
    $userId = $_SESSION['user_id'];
    
    try {
        $database = new Database();
        $db = $database->getConnection();

        // Get user's subscription ID
        $userQuery = "SELECT stripe_subscription_id FROM users WHERE id = :user_id";
        $userStmt = $db->prepare($userQuery);
        $userStmt->bindParam(':user_id', $userId);
        $userStmt->execute();
        $user = $userStmt->fetch();

        if (!$user || !$user['stripe_subscription_id']) {
            http_response_code(404);
            echo json_encode(['error' => 'No active subscription found']);
            return;
        }

        // Cancel subscription in Stripe
        $subscription = \Stripe\Subscription::retrieve($user['stripe_subscription_id']);
        $subscription->cancel();

        // Update user subscription info
        $updateQuery = "UPDATE users SET 
                       subscription_status = 'canceled',
                       canceled_at = NOW()
                       WHERE id = :user_id";
        $updateStmt = $db->prepare($updateQuery);
        $updateStmt->bindParam(':user_id', $userId);
        $updateStmt->execute();

        // Update session
        $_SESSION['subscription_status'] = 'canceled';

        echo json_encode([
            'success' => true,
            'message' => 'Subscription canceled successfully'
        ]);

    } catch (Exception $e) {
        error_log("Cancel subscription error: " . $e->getMessage());
        http_response_code(500);
        echo json_encode(['error' => 'Failed to cancel subscription']);
    }
}

function updatePaymentMethod($input) {
    if (!isset($input['payment_method_id'])) {
        http_response_code(400);
        echo json_encode(['error' => 'Payment method ID is required']);
        return;
    }

    $userId = $_SESSION['user_id'];
    $paymentMethodId = $input['payment_method_id'];
    
    try {
        $database = new Database();
        $db = $database->getConnection();

        // Get user's customer ID
        $userQuery = "SELECT stripe_customer_id FROM users WHERE id = :user_id";
        $userStmt = $db->prepare($userQuery);
        $userStmt->bindParam(':user_id', $userId);
        $userStmt->execute();
        $user = $userStmt->fetch();

        if (!$user || !$user['stripe_customer_id']) {
            http_response_code(404);
            echo json_encode(['error' => 'Customer not found']);
            return;
        }

        // Attach new payment method
        $paymentMethod = \Stripe\PaymentMethod::retrieve($paymentMethodId);
        $paymentMethod->attach(['customer' => $user['stripe_customer_id']]);

        // Update customer's default payment method
        \Stripe\Customer::update($user['stripe_customer_id'], [
            'invoice_settings' => [
                'default_payment_method' => $paymentMethodId,
            ],
        ]);

        echo json_encode([
            'success' => true,
            'message' => 'Payment method updated successfully'
        ]);

    } catch (Exception $e) {
        error_log("Update payment method error: " . $e->getMessage());
        http_response_code(500);
        echo json_encode(['error' => 'Failed to update payment method']);
    }
}
?>
