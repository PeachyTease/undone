<?php
require_once '../config/session.php';
require_once '../config/database.php';
require_once '../config/stripe.php';

if (file_exists('../../vendor/autoload.php')) {
    require_once '../../vendor/autoload.php';
}

header('Content-Type: application/json');
requireAuth();
checkSessionExpiry();

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['error' => 'Method not allowed']);
    exit;
}

try {
    if (class_exists('\Stripe\Stripe')) {
        \Stripe\Stripe::setApiKey(StripeConfig::getSecretKey());
    } else {
        throw new Exception('Stripe library not found');
    }

    $userId = $_SESSION['user_id'];
    
    $database = new Database();
    $db = $database->getConnection();

    // Get user's subscription ID
    $userQuery = "SELECT stripe_subscription_id FROM users WHERE id = :user_id";
    $userStmt = $db->prepare($userQuery);
    $userStmt->bindParam(':user_id', $userId);
    $userStmt->execute();
    $user = $userStmt->fetch();

    if (!$user || !$user['stripe_subscription_id']) {
        http_response_code(404);
        echo json_encode(['error' => 'No active subscription found']);
        exit;
    }

    // Cancel subscription in Stripe
    $subscription = \Stripe\Subscription::retrieve($user['stripe_subscription_id']);
    $subscription->cancel();

    // Update user subscription info
    $updateQuery = "UPDATE users SET 
                   subscription_status = 'canceled',
                   canceled_at = NOW(),
                   updated_at = NOW()
                   WHERE id = :user_id";
    $updateStmt = $db->prepare($updateQuery);
    $updateStmt->bindParam(':user_id', $userId);
    $updateStmt->execute();

    // Update session
    $_SESSION['subscription_status'] = 'canceled';

    echo json_encode([
        'success' => true,
        'message' => 'Subscription canceled successfully'
    ]);

} catch (Exception $e) {
    error_log("Cancel subscription error: " . $e->getMessage());
    http_response_code(500);
    echo json_encode(['error' => 'Failed to cancel subscription']);
}
?>
