<?php
require_once '../config/session.php';
require_once '../config/database.php';
require_once '../config/stripe.php';

// For GoDaddy hosting, you may need to manually include Stripe files
// if Composer is not available
if (file_exists('../../vendor/autoload.php')) {
    require_once '../../vendor/autoload.php';
} else {
    // Manual include for Stripe library if needed
    // require_once '../lib/stripe/init.php';
}

header('Content-Type: application/json');
requireAuth();
checkSessionExpiry();

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['error' => 'Method not allowed']);
    exit;
}

try {
    // Set Stripe API key
    if (class_exists('\Stripe\Stripe')) {
        \Stripe\Stripe::setApiKey(StripeConfig::getSecretKey());
    } else {
        throw new Exception('Stripe library not found');
    }

    $input = json_decode(file_get_contents('php://input'), true);
    
    if (!isset($input['payment_method_id']) || !isset($input['plan'])) {
        http_response_code(400);
        echo json_encode(['error' => 'Payment method and plan are required']);
        exit;
    }

    $userId = $_SESSION['user_id'];
    $planId = $input['plan'];
    $paymentMethodId = $input['payment_method_id'];
    $cardholderName = $input['cardholder_name'] ?? '';
    
    $priceIds = StripeConfig::getPriceIds();
    
    if (!isset($priceIds[$planId])) {
        http_response_code(400);
        echo json_encode(['error' => 'Invalid plan']);
        exit;
    }

    $database = new Database();
    $db = $database->getConnection();

    // Get user details
    $userQuery = "SELECT email, first_name, last_name, stripe_customer_id FROM users WHERE id = :user_id";
    $userStmt = $db->prepare($userQuery);
    $userStmt->bindParam(':user_id', $userId);
    $userStmt->execute();
    $user = $userStmt->fetch();

    if (!$user) {
        http_response_code(404);
        echo json_encode(['error' => 'User not found']);
        exit;
    }

    // Create or retrieve Stripe customer
    $customerId = $user['stripe_customer_id'];
    
    if (!$customerId) {
        $customer = \Stripe\Customer::create([
            'email' => $user['email'],
            'name' => $cardholderName ?: ($user['first_name'] . ' ' . $user['last_name']),
            'payment_method' => $paymentMethodId,
            'invoice_settings' => [
                'default_payment_method' => $paymentMethodId,
            ],
        ]);
        $customerId = $customer->id;

        // Update user with customer ID
        $updateCustomerQuery = "UPDATE users SET stripe_customer_id = :customer_id WHERE id = :user_id";
        $updateCustomerStmt = $db->prepare($updateCustomerQuery);
        $updateCustomerStmt->bindParam(':customer_id', $customerId);
        $updateCustomerStmt->bindParam(':user_id', $userId);
        $updateCustomerStmt->execute();
    } else {
        // Attach payment method to existing customer
        $paymentMethod = \Stripe\PaymentMethod::retrieve($paymentMethodId);
        $paymentMethod->attach(['customer' => $customerId]);

        // Update default payment method
        \Stripe\Customer::update($customerId, [
            'invoice_settings' => [
                'default_payment_method' => $paymentMethodId,
            ],
        ]);
    }

    // Create subscription with trial period
    $subscription = \Stripe\Subscription::create([
        'customer' => $customerId,
        'items' => [
            ['price' => $priceIds[$planId]],
        ],
        'trial_period_days' => 7,
        'payment_behavior' => 'default_incomplete',
        'payment_settings' => ['save_default_payment_method' => 'on_subscription'],
        'expand' => ['latest_invoice.payment_intent'],
    ]);

    $paymentIntent = $subscription->latest_invoice->payment_intent ?? null;

    if ($paymentIntent && $paymentIntent->status === 'requires_action') {
        echo json_encode([
            'requires_action' => true,
            'payment_intent' => [
                'id' => $paymentIntent->id,
                'client_secret' => $paymentIntent->client_secret
            ]
        ]);
    } else if ($subscription->status === 'trialing' || ($paymentIntent && $paymentIntent->status === 'succeeded')) {
        // Update user subscription info
        $trialEndsAt = date('Y-m-d H:i:s', time() + 7 * 86400); // 7 days from now
        $updatedAt = date('Y-m-d H:i:s');
        
        $updateSubQuery = "UPDATE users SET 
                          subscription_plan = :plan,
                          subscription_status = :status,
                          stripe_subscription_id = :subscription_id,
                          trial_ends_at = :trial_ends_at,
                          updated_at = :updated_at
                          WHERE id = :user_id";
        $updateSubStmt = $db->prepare($updateSubQuery);
        $updateSubStmt->bindParam(':plan', $planId);
        $updateSubStmt->bindParam(':status', $subscription->status);
        $updateSubStmt->bindParam(':subscription_id', $subscription->id);
        $updateSubStmt->bindParam(':trial_ends_at', $trialEndsAt);
        $updateSubStmt->bindParam(':updated_at', $updatedAt);
        $updateSubStmt->bindParam(':user_id', $userId);
        $updateSubStmt->execute();

        // Update session
        $_SESSION['subscription_plan'] = $planId;
        $_SESSION['subscription_status'] = $subscription->status;

        echo json_encode([
            'success' => true,
            'subscription' => [
                'id' => $subscription->id,
                'status' => $subscription->status,
                'plan' => $planId,
                'trial_end' => $subscription->trial_end
            ]
        ]);
    } else {
        echo json_encode([
            'error' => 'Payment failed'
        ]);
    }

} catch (\Stripe\Exception\CardException $e) {
    http_response_code(402);
    echo json_encode(['error' => $e->getError()->message]);
} catch (Exception $e) {
    error_log("Payment creation error: " . $e->getMessage());
    http_response_code(500);
    echo json_encode(['error' => 'Payment processing failed: ' . $e->getMessage()]);
}
?>
