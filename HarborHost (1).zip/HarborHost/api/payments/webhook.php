<?php
require_once '../config/database.php';
require_once '../config/stripe.php';

if (file_exists('../../vendor/autoload.php')) {
    require_once '../../vendor/autoload.php';
}

header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    exit;
}

$payload = @file_get_contents('php://input');
$sig_header = $_SERVER['HTTP_STRIPE_SIGNATURE'] ?? '';
$endpoint_secret = StripeConfig::getWebhookSecret();

try {
    if (class_exists('\Stripe\Stripe')) {
        \Stripe\Stripe::setApiKey(StripeConfig::getSecretKey());
        $event = \Stripe\Webhook::constructEvent($payload, $sig_header, $endpoint_secret);
    } else {
        throw new Exception('Stripe library not found');
    }

    $database = new Database();
    $db = $database->getConnection();

    // Handle the event
    switch ($event->type) {
        case 'customer.subscription.updated':
            $subscription = $event->data->object;
            updateSubscriptionStatus($db, $subscription);
            break;

        case 'customer.subscription.deleted':
            $subscription = $event->data->object;
            cancelSubscription($db, $subscription);
            break;

        case 'invoice.payment_succeeded':
            $invoice = $event->data->object;
            handleSuccessfulPayment($db, $invoice);
            break;

        case 'invoice.payment_failed':
            $invoice = $event->data->object;
            handleFailedPayment($db, $invoice);
            break;

        default:
            error_log('Unhandled event type: ' . $event->type);
    }

    http_response_code(200);
    echo json_encode(['status' => 'success']);

} catch (\Stripe\Exception\SignatureVerificationException $e) {
    error_log('Webhook signature verification failed: ' . $e->getMessage());
    http_response_code(400);
    exit;
} catch (Exception $e) {
    error_log('Webhook error: ' . $e->getMessage());
    http_response_code(500);
    exit;
}

function updateSubscriptionStatus($db, $subscription) {
    try {
        $updatedAt = date('Y-m-d H:i:s');
        $query = "UPDATE users SET 
                  subscription_status = :status,
                  updated_at = :updated_at
                  WHERE stripe_subscription_id = :subscription_id";
        $stmt = $db->prepare($query);
        $stmt->bindParam(':status', $subscription->status);
        $stmt->bindParam(':subscription_id', $subscription->id);
        $stmt->bindParam(':updated_at', $updatedAt);
        $stmt->execute();
    } catch (Exception $e) {
        error_log('Error updating subscription status: ' . $e->getMessage());
    }
}

function cancelSubscription($db, $subscription) {
    try {
        $canceledAt = date('Y-m-d H:i:s');
        $updatedAt = date('Y-m-d H:i:s');
        $query = "UPDATE users SET 
                  subscription_status = 'canceled',
                  canceled_at = :canceled_at,
                  updated_at = :updated_at
                  WHERE stripe_subscription_id = :subscription_id";
        $stmt = $db->prepare($query);
        $stmt->bindParam(':subscription_id', $subscription->id);
        $stmt->bindParam(':canceled_at', $canceledAt);
        $stmt->bindParam(':updated_at', $updatedAt);
        $stmt->execute();
    } catch (Exception $e) {
        error_log('Error canceling subscription: ' . $e->getMessage());
    }
}

function handleSuccessfulPayment($db, $invoice) {
    try {
        if ($invoice->subscription) {
            $lastPaymentAt = date('Y-m-d H:i:s');
            $updatedAt = date('Y-m-d H:i:s');
            $query = "UPDATE users SET 
                      subscription_status = 'active',
                      last_payment_at = :last_payment_at,
                      updated_at = :updated_at
                      WHERE stripe_subscription_id = :subscription_id";
            $stmt = $db->prepare($query);
            $stmt->bindParam(':subscription_id', $invoice->subscription);
            $stmt->bindParam(':last_payment_at', $lastPaymentAt);
            $stmt->bindParam(':updated_at', $updatedAt);
            $stmt->execute();
        }
    } catch (Exception $e) {
        error_log('Error handling successful payment: ' . $e->getMessage());
    }
}

function handleFailedPayment($db, $invoice) {
    try {
        if ($invoice->subscription) {
            $updatedAt = date('Y-m-d H:i:s');
            $query = "UPDATE users SET 
                      subscription_status = 'past_due',
                      updated_at = :updated_at
                      WHERE stripe_subscription_id = :subscription_id";
            $stmt = $db->prepare($query);
            $stmt->bindParam(':subscription_id', $invoice->subscription);
            $stmt->bindParam(':updated_at', $updatedAt);
            $stmt->execute();
        }
    } catch (Exception $e) {
        error_log('Error handling failed payment: ' . $e->getMessage());
    }
}
?>
