<?php
session_start();
require_once '../config/database.php';

header('Content-Type: application/json');

if (!isset($_SESSION['user_id'])) {
    http_response_code(401);
    echo json_encode(['error' => 'User not authenticated']);
    exit;
}

$method = $_SERVER['REQUEST_METHOD'];

try {
    switch ($method) {
        case 'GET':
            getUserProfile();
            break;
        case 'PUT':
            updateUserProfile();
            break;
        default:
            http_response_code(405);
            echo json_encode(['error' => 'Method not allowed']);
    }

} catch (Exception $e) {
    error_log("User API error: " . $e->getMessage());
    http_response_code(500);
    echo json_encode(['error' => 'An error occurred']);
}

function getUserProfile() {
    $userId = $_SESSION['user_id'];
    
    $database = new Database();
    $db = $database->getConnection();

    $query = "SELECT id, first_name, last_name, email, subscription_plan, subscription_status, 
                     trial_ends_at, created_at, last_login
              FROM users WHERE id = :user_id";
    $stmt = $db->prepare($query);
    $stmt->bindParam(':user_id', $userId);
    $stmt->execute();

    $user = $stmt->fetch();

    if ($user) {
        echo json_encode([
            'success' => true,
            'user' => $user
        ]);
    } else {
        http_response_code(404);
        echo json_encode(['error' => 'User not found']);
    }
}

function updateUserProfile() {
    $userId = $_SESSION['user_id'];
    $input = json_decode(file_get_contents('php://input'), true);
    
    $allowedFields = ['first_name', 'last_name', 'email'];
    $updateFields = [];
    $params = [':user_id' => $userId];
    
    foreach ($allowedFields as $field) {
        if (isset($input[$field]) && !empty(trim($input[$field]))) {
            if ($field === 'email') {
                $email = filter_var(trim($input[$field]), FILTER_SANITIZE_EMAIL);
                if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
                    http_response_code(400);
                    echo json_encode(['error' => 'Invalid email format']);
                    return;
                }
                $updateFields[] = "email = :email";
                $params[':email'] = $email;
            } else {
                $updateFields[] = "$field = :$field";
                $params[":$field"] = trim($input[$field]);
            }
        }
    }
    
    if (empty($updateFields)) {
        http_response_code(400);
        echo json_encode(['error' => 'No valid fields to update']);
        return;
    }

    $database = new Database();
    $db = $database->getConnection();

    // Check if email is already taken by another user
    if (isset($params[':email'])) {
        $checkQuery = "SELECT id FROM users WHERE email = :email AND id != :user_id";
        $checkStmt = $db->prepare($checkQuery);
        $checkStmt->bindParam(':email', $params[':email']);
        $checkStmt->bindParam(':user_id', $userId);
        $checkStmt->execute();
        
        if ($checkStmt->fetch()) {
            http_response_code(409);
            echo json_encode(['error' => 'Email already taken']);
            return;
        }
    }

    $query = "UPDATE users SET " . implode(', ', $updateFields) . " WHERE id = :user_id";
    $stmt = $db->prepare($query);
    
    foreach ($params as $param => $value) {
        $stmt->bindValue($param, $value);
    }

    if ($stmt->execute()) {
        // Update session if name was changed
        if (isset($params[':first_name']) || isset($params[':last_name'])) {
            $nameQuery = "SELECT first_name, last_name FROM users WHERE id = :user_id";
            $nameStmt = $db->prepare($nameQuery);
            $nameStmt->bindParam(':user_id', $userId);
            $nameStmt->execute();
            $nameResult = $nameStmt->fetch();
            
            $_SESSION['user_name'] = $nameResult['first_name'] . ' ' . $nameResult['last_name'];
        }
        
        if (isset($params[':email'])) {
            $_SESSION['user_email'] = $params[':email'];
        }

        echo json_encode([
            'success' => true,
            'message' => 'Profile updated successfully'
        ]);
    } else {
        http_response_code(500);
        echo json_encode(['error' => 'Failed to update profile']);
    }
}
?>
