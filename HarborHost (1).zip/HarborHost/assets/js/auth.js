// Authentication functionality for HopeHarbor

function handleLogin(event) {
    event.preventDefault();
    
    const form = event.target;
    const formData = new FormData(form);
    const email = formData.get('email');
    const password = formData.get('password');
    const remember = formData.get('remember');
    
    // Validate input
    if (!email || !password) {
        showAuthError('Please fill in all fields');
        return;
    }
    
    if (!validateEmail(email)) {
        showAuthError('Please enter a valid email address');
        return;
    }
    
    // Show loading state
    const submitButton = form.querySelector('button[type="submit"]');
    const originalText = submitButton.textContent;
    submitButton.textContent = 'Signing In...';
    submitButton.disabled = true;
    
    // Clear previous errors
    clearAuthErrors();
    
    // Make login request
    fetch('/api/auth/login.php', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
        },
        credentials: 'include',
        body: JSON.stringify({
            email: email,
            password: password,
            remember: remember
        })
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            currentUser = data.user;
            closeModal('authModal');
            updateUIForAuthenticatedUser();
            showNotification('Welcome back! You have been successfully logged in.', 'success');
            
            // Redirect to dashboard if they were trying to access a protected feature
            if (window.pendingAction) {
                window.pendingAction();
                window.pendingAction = null;
            }
        } else {
            showAuthError(data.error || 'Login failed');
        }
    })
    .catch(error => {
        console.error('Login error:', error);
        showAuthError('An error occurred during login. Please try again.');
    })
    .finally(() => {
        // Reset button state
        submitButton.textContent = originalText;
        submitButton.disabled = false;
    });
}

function handleSignup(event) {
    event.preventDefault();
    
    const form = event.target;
    const formData = new FormData(form);
    const firstName = formData.get('firstName');
    const lastName = formData.get('lastName');
    const email = formData.get('email');
    const password = formData.get('password');
    const terms = formData.get('terms');
    
    // Validate input
    if (!firstName || !lastName || !email || !password) {
        showAuthError('Please fill in all fields');
        return;
    }
    
    if (!validateEmail(email)) {
        showAuthError('Please enter a valid email address');
        return;
    }
    
    if (!validatePassword(password)) {
        showAuthError('Password must be at least 8 characters long');
        return;
    }
    
    if (!terms) {
        showAuthError('Please agree to the Terms of Service and Privacy Policy');
        return;
    }
    
    // Show loading state
    const submitButton = form.querySelector('button[type="submit"]');
    const originalText = submitButton.textContent;
    submitButton.textContent = 'Creating Account...';
    submitButton.disabled = true;
    
    // Clear previous errors
    clearAuthErrors();
    
    // Make signup request
    fetch('/api/auth/register.php', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
        },
        credentials: 'include',
        body: JSON.stringify({
            firstName: firstName,
            lastName: lastName,
            email: email,
            password: password
        })
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            currentUser = data.user;
            closeModal('authModal');
            updateUIForAuthenticatedUser();
            showNotification('Welcome to HopeHarbor! Your account has been created successfully.', 'success');
            
            // Show welcome message and guide to next steps
            setTimeout(() => {
                showWelcomeMessage();
            }, 1000);
        } else {
            showAuthError(data.error || 'Registration failed');
        }
    })
    .catch(error => {
        console.error('Signup error:', error);
        showAuthError('An error occurred during registration. Please try again.');
    })
    .finally(() => {
        // Reset button state
        submitButton.textContent = originalText;
        submitButton.disabled = false;
    });
}

function showAuthError(message) {
    // Find or create error element in the active auth form
    const activeForm = document.querySelector('.auth-form[style*="block"], .auth-form:not([style*="none"])');
    if (!activeForm) return;
    
    let errorElement = activeForm.querySelector('.auth-error');
    if (!errorElement) {
        errorElement = document.createElement('div');
        errorElement.className = 'auth-error error-message';
        errorElement.style.cssText = `
            color: var(--destructive);
            font-size: 0.875rem;
            margin-top: 1rem;
            padding: 0.75rem;
            background: hsl(0, 84.2%, 97%);
            border: 1px solid hsl(0, 84.2%, 90%);
            border-radius: 0.375rem;
        `;
        
        // Insert before the submit button
        const submitButton = activeForm.querySelector('button[type="submit"]');
        if (submitButton) {
            submitButton.parentNode.insertBefore(errorElement, submitButton);
        } else {
            activeForm.appendChild(errorElement);
        }
    }
    
    errorElement.textContent = message;
    errorElement.style.display = 'block';
    
    // Scroll error into view if needed
    errorElement.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
}

function clearAuthErrors() {
    const errorElements = document.querySelectorAll('.auth-error');
    errorElements.forEach(element => {
        element.style.display = 'none';
        element.textContent = '';
    });
}

function showWelcomeMessage() {
    const welcomeHtml = `
        <div class="welcome-overlay" style="
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(0, 0, 0, 0.8);
            z-index: 1003;
            display: flex;
            align-items: center;
            justify-content: center;
        ">
            <div class="welcome-content" style="
                background: white;
                padding: 2rem;
                border-radius: 1rem;
                max-width: 28rem;
                width: 90%;
                text-align: center;
                box-shadow: 0 25px 50px rgba(0, 0, 0, 0.25);
            ">
                <div style="
                    width: 4rem;
                    height: 4rem;
                    background: var(--primary);
                    border-radius: 50%;
                    display: flex;
                    align-items: center;
                    justify-content: center;
                    margin: 0 auto 1.5rem;
                ">
                    <i class="fas fa-check" style="color: white; font-size: 1.5rem;"></i>
                </div>
                
                <h3 style="
                    font-size: 1.5rem;
                    font-weight: 700;
                    color: var(--foreground);
                    margin-bottom: 1rem;
                ">Welcome to HopeHarbor!</h3>
                
                <p style="
                    color: var(--muted-foreground);
                    margin-bottom: 2rem;
                    line-height: 1.6;
                ">Your account has been created successfully. Ready to start your mental health journey?</p>
                
                <div style="display: flex; gap: 1rem; justify-content: center;">
                    <button onclick="closeWelcomeMessage(); selectPlan('premium', 79);" class="btn btn-primary">
                        Choose a Plan
                    </button>
                    <button onclick="closeWelcomeMessage();" class="btn btn-secondary">
                        Explore First
                    </button>
                </div>
            </div>
        </div>
    `;
    
    document.body.insertAdjacentHTML('beforeend', welcomeHtml);
}

function closeWelcomeMessage() {
    const welcomeOverlay = document.querySelector('.welcome-overlay');
    if (welcomeOverlay) {
        welcomeOverlay.remove();
    }
}

function requestPasswordReset(email) {
    if (!email || !validateEmail(email)) {
        showAuthError('Please enter a valid email address');
        return;
    }
    
    fetch('/api/auth/reset-password.php', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
        },
        body: JSON.stringify({ email: email })
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            showNotification('Password reset instructions have been sent to your email', 'success');
            closeModal('authModal');
        } else {
            showAuthError(data.error || 'Failed to send reset email');
        }
    })
    .catch(error => {
        console.error('Password reset error:', error);
        showAuthError('An error occurred. Please try again.');
    });
}

// Add forgot password functionality
document.addEventListener('DOMContentLoaded', function() {
    // Add click handler for forgot password link
    document.addEventListener('click', function(e) {
        if (e.target.classList.contains('forgot-link')) {
            e.preventDefault();
            
            const emailInput = document.querySelector('#loginForm input[name="email"]');
            const email = emailInput ? emailInput.value : '';
            
            if (!email) {
                showAuthError('Please enter your email address first');
                return;
            }
            
            if (confirm(`Send password reset instructions to ${email}?`)) {
                requestPasswordReset(email);
            }
        }
    });
});

// Password strength checker
function checkPasswordStrength(password) {
    const checks = {
        length: password.length >= 8,
        uppercase: /[A-Z]/.test(password),
        lowercase: /[a-z]/.test(password),
        number: /\d/.test(password),
        special: /[!@#$%^&*(),.?":{}|<>]/.test(password)
    };
    
    const score = Object.values(checks).filter(Boolean).length;
    
    return {
        score: score,
        checks: checks,
        strength: score < 2 ? 'weak' : score < 4 ? 'medium' : 'strong'
    };
}

// Add password strength indicator
function addPasswordStrengthIndicator() {
    const passwordInputs = document.querySelectorAll('input[type="password"]');
    
    passwordInputs.forEach(input => {
        // Skip if this is a login form password
        if (input.closest('#loginForm')) return;
        
        input.addEventListener('input', function() {
            const strength = checkPasswordStrength(this.value);
            
            let indicator = this.parentNode.querySelector('.password-strength');
            if (!indicator && this.value) {
                indicator = document.createElement('div');
                indicator.className = 'password-strength';
                indicator.style.cssText = `
                    font-size: 0.75rem;
                    margin-top: 0.25rem;
                    display: flex;
                    align-items: center;
                    gap: 0.5rem;
                `;
                this.parentNode.appendChild(indicator);
            }
            
            if (indicator) {
                if (!this.value) {
                    indicator.style.display = 'none';
                    return;
                }
                
                indicator.style.display = 'flex';
                
                const colors = {
                    weak: '#ef4444',
                    medium: '#f59e0b', 
                    strong: '#10b981'
                };
                
                indicator.innerHTML = `
                    <div style="
                        width: 1rem;
                        height: 1rem;
                        border-radius: 50%;
                        background: ${colors[strength.strength]};
                    "></div>
                    <span style="color: ${colors[strength.strength]};">
                        ${strength.strength.charAt(0).toUpperCase() + strength.strength.slice(1)} password
                    </span>
                `;
            }
        });
    });
}

// Initialize password strength indicators when DOM is loaded
document.addEventListener('DOMContentLoaded', addPasswordStrengthIndicator);
