// Main JavaScript functionality for HopeHarbor

// Global variables
let currentUser = null;
let mobileMenuOpen = false;

// Initialize the application
document.addEventListener('DOMContentLoaded', function() {
    initializeApp();
    setupEventListeners();
    checkAuthStatus();
});

function initializeApp() {
    // Set up smooth scrolling
    setupSmoothScrolling();
    
    // Initialize mobile menu
    setupMobileMenu();
    
    // Check for authentication status
    checkAuthStatus();
}

function setupEventListeners() {
    // Modal backdrop clicks
    document.addEventListener('click', function(e) {
        if (e.target.classList.contains('modal')) {
            closeModal(e.target.id);
        }
    });

    // Escape key to close modals
    document.addEventListener('keydown', function(e) {
        if (e.key === 'Escape') {
            closeAllModals();
        }
    });

    // Session timeout check
    setInterval(checkSessionTimeout, 60000); // Check every minute
}

function setupSmoothScrolling() {
    document.querySelectorAll('a[href^="#"]').forEach(anchor => {
        anchor.addEventListener('click', function (e) {
            e.preventDefault();
            const target = document.querySelector(this.getAttribute('href'));
            if (target) {
                target.scrollIntoView({
                    behavior: 'smooth',
                    block: 'start'
                });
            }
        });
    });
}

function setupMobileMenu() {
    const toggle = document.querySelector('.mobile-menu-toggle');
    const mobileNav = document.querySelector('.mobile-nav');
    
    if (toggle && mobileNav) {
        toggle.addEventListener('click', function() {
            mobileMenuOpen = !mobileMenuOpen;
            mobileNav.classList.toggle('active', mobileMenuOpen);
            
            // Update icon
            const icon = toggle.querySelector('i');
            if (icon) {
                icon.className = mobileMenuOpen ? 'fas fa-times' : 'fas fa-bars';
            }
        });
    }
}

function scrollToSection(sectionId) {
    const element = document.getElementById(sectionId);
    if (element) {
        element.scrollIntoView({
            behavior: 'smooth',
            block: 'start'
        });
    }
}

// Modal functions
function showAuthModal(mode = 'login') {
    const modal = document.getElementById('authModal');
    const loginForm = document.getElementById('loginForm');
    const signupForm = document.getElementById('signupForm');
    const title = document.getElementById('authModalTitle');
    const subtitle = document.getElementById('authModalSubtitle');
    
    if (mode === 'login') {
        loginForm.style.display = 'block';
        signupForm.style.display = 'none';
        title.textContent = 'Welcome Back';
        subtitle.textContent = 'Sign in to your HopeHarbor account';
    } else {
        loginForm.style.display = 'none';
        signupForm.style.display = 'block';
        title.textContent = 'Join HopeHarbor';
        subtitle.textContent = 'Start your journey to better mental health';
    }
    
    modal.classList.add('active');
    
    // Focus first input
    setTimeout(() => {
        const firstInput = modal.querySelector('input[type="email"]');
        if (firstInput) firstInput.focus();
    }, 100);
}

function switchAuthMode(mode) {
    showAuthModal(mode);
}

function closeModal(modalId) {
    const modal = document.getElementById(modalId);
    if (modal) {
        modal.classList.remove('active');
        
        // Clear form data
        const forms = modal.querySelectorAll('form');
        forms.forEach(form => form.reset());
        
        // Clear error messages
        const errors = modal.querySelectorAll('.error-message');
        errors.forEach(error => error.textContent = '');
    }
}

function closeAllModals() {
    const modals = document.querySelectorAll('.modal');
    modals.forEach(modal => {
        modal.classList.remove('active');
    });
}

function showServiceModal(serviceType) {
    const serviceInfo = {
        telehealth: {
            title: 'Telehealth Sessions',
            content: 'Connect with licensed therapists through secure, HIPAA-compliant video sessions. Available 24/7 with flexible scheduling.',
            features: ['Licensed professionals', 'Secure video calls', 'Flexible scheduling', 'Treatment notes']
        },
        groups: {
            title: 'Support Groups',
            content: 'Join peer-led support groups for various conditions including anxiety, depression, addiction recovery, and grief support.',
            features: ['Peer support', 'Facilitated sessions', 'Various topics', 'Safe environment']
        },
        tools: {
            title: 'Wellness Tools',
            content: 'Access a comprehensive suite of mental health tools including mood tracking, meditation guides, and coping strategies.',
            features: ['Mood tracking', 'Guided meditation', 'Coping strategies', 'Progress monitoring']
        },
        crisis: {
            title: '24/7 Crisis Support',
            content: 'Immediate access to crisis counselors when you need support the most. Available 24/7 for urgent mental health needs.',
            features: ['24/7 availability', 'Crisis counselors', 'Immediate support', 'Emergency resources']
        },
        resources: {
            title: 'Resource Library',
            content: 'Explore our extensive library of articles, worksheets, and educational content curated by mental health experts.',
            features: ['Expert articles', 'Downloadable worksheets', 'Educational videos', 'Self-help guides']
        },
        family: {
            title: 'Family Support',
            content: 'Specialized programs and resources for families and loved ones affected by mental health challenges.',
            features: ['Family counseling', 'Support resources', 'Educational materials', 'Group sessions']
        }
    };

    const service = serviceInfo[serviceType];
    if (!service) return;

    showInfoModal(service.title, service.content, service.features);
}

function showInfoModal(title, content, features) {
    const modalHtml = `
        <div class="info-modal" style="
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(0, 0, 0, 0.5);
            z-index: 1003;
            display: flex;
            align-items: center;
            justify-content: center;
        ">
            <div class="info-content" style="
                background: white;
                padding: 2rem;
                border-radius: 1rem;
                max-width: 32rem;
                width: 90%;
                box-shadow: 0 25px 50px rgba(0, 0, 0, 0.25);
                position: relative;
            ">
                <button onclick="closeInfoModal()" style="
                    position: absolute;
                    top: 1rem;
                    right: 1rem;
                    background: none;
                    border: none;
                    font-size: 1.5rem;
                    color: var(--muted-foreground);
                    cursor: pointer;
                ">
                    <i class="fas fa-times"></i>
                </button>
                
                <h3 style="
                    font-size: 1.5rem;
                    font-weight: 700;
                    color: var(--foreground);
                    margin-bottom: 1rem;
                ">${title}</h3>
                
                <p style="
                    color: var(--muted-foreground);
                    margin-bottom: 1.5rem;
                    line-height: 1.6;
                ">${content}</p>
                
                <h4 style="
                    font-size: 1.125rem;
                    font-weight: 600;
                    color: var(--foreground);
                    margin-bottom: 1rem;
                ">Key Features:</h4>
                
                <ul style="
                    list-style: none;
                    margin-bottom: 2rem;
                ">
                    ${features.map(feature => `
                        <li style="
                            display: flex;
                            align-items: center;
                            gap: 0.75rem;
                            margin-bottom: 0.5rem;
                            color: var(--foreground);
                        ">
                            <i class="fas fa-check" style="color: #10b981;"></i>
                            ${feature}
                        </li>
                    `).join('')}
                </ul>
                
                <div style="display: flex; gap: 1rem;">
                    <button onclick="showAuthModal('signup')" class="btn btn-primary" style="flex: 1;">
                        Get Started
                    </button>
                    <button onclick="closeInfoModal()" class="btn btn-secondary" style="flex: 1;">
                        Close
                    </button>
                </div>
            </div>
        </div>
    `;
    
    document.body.insertAdjacentHTML('beforeend', modalHtml);
}

function closeInfoModal() {
    const infoModal = document.querySelector('.info-modal');
    if (infoModal) {
        infoModal.remove();
    }
}

function showContactModal() {
    const modalHtml = `
        <div class="contact-modal" style="
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(0, 0, 0, 0.5);
            z-index: 1003;
            display: flex;
            align-items: center;
            justify-content: center;
        ">
            <div class="contact-content" style="
                background: white;
                padding: 2rem;
                border-radius: 1rem;
                max-width: 32rem;
                width: 90%;
                box-shadow: 0 25px 50px rgba(0, 0, 0, 0.25);
                position: relative;
            ">
                <button onclick="closeContactModal()" style="
                    position: absolute;
                    top: 1rem;
                    right: 1rem;
                    background: none;
                    border: none;
                    font-size: 1.5rem;
                    color: var(--muted-foreground);
                    cursor: pointer;
                ">
                    <i class="fas fa-times"></i>
                </button>
                
                <h3 style="
                    font-size: 1.5rem;
                    font-weight: 700;
                    color: var(--foreground);
                    margin-bottom: 1rem;
                ">Schedule a Consultation</h3>
                
                <p style="
                    color: var(--muted-foreground);
                    margin-bottom: 1.5rem;
                    line-height: 1.6;
                ">Get personalized guidance from our mental health professionals. Schedule a free 15-minute consultation to discuss your needs.</p>
                
                <form onsubmit="handleContactForm(event)">
                    <div class="form-group">
                        <label>Full Name</label>
                        <input type="text" name="name" required>
                    </div>
                    <div class="form-group">
                        <label>Email</label>
                        <input type="email" name="email" required>
                    </div>
                    <div class="form-group">
                        <label>Phone (Optional)</label>
                        <input type="tel" name="phone">
                    </div>
                    <div class="form-group">
                        <label>Preferred Time</label>
                        <select name="time" required>
                            <option value="">Select a time</option>
                            <option value="morning">Morning (9 AM - 12 PM)</option>
                            <option value="afternoon">Afternoon (12 PM - 5 PM)</option>
                            <option value="evening">Evening (5 PM - 8 PM)</option>
                        </select>
                    </div>
                    <div class="form-group">
                        <label>How can we help you? (Optional)</label>
                        <textarea name="message" rows="3" placeholder="Tell us about your needs or any specific concerns..."></textarea>
                    </div>
                    
                    <button type="submit" class="btn btn-primary btn-full">
                        Schedule Consultation
                    </button>
                </form>
            </div>
        </div>
    `;
    
    document.body.insertAdjacentHTML('beforeend', modalHtml);
}

function closeContactModal() {
    const contactModal = document.querySelector('.contact-modal');
    if (contactModal) {
        contactModal.remove();
    }
}

function handleContactForm(event) {
    event.preventDefault();
    
    const form = event.target;
    const formData = new FormData(form);
    
    // Show loading state
    const submitButton = form.querySelector('button[type="submit"]');
    const originalText = submitButton.textContent;
    submitButton.textContent = 'Scheduling...';
    submitButton.disabled = true;
    
    // Simulate API call
    setTimeout(() => {
        closeContactModal();
        showNotification('Consultation request received! We\'ll contact you within 24 hours.', 'success');
        
        // In real implementation, send to backend
        // fetch('/api/contact.php', {
        //     method: 'POST',
        //     headers: { 'Content-Type': 'application/json' },
        //     body: JSON.stringify(Object.fromEntries(formData))
        // })
    }, 1000);
}

// Plan selection
function selectPlan(planName, price) {
    if (!currentUser) {
        // Store selected plan for after login
        window.selectedPlan = { name: planName, price: price };
        window.pendingAction = () => showPaymentModal(planName, price);
        showAuthModal('signup');
        return;
    }
    
    // Store selected plan details
    window.selectedPlan = {
        name: planName,
        price: price
    };
    
    // Show payment modal
    showPaymentModal(planName, price);
}

function showPaymentModal(planName, price) {
    const modal = document.getElementById('paymentModal');
    const planNameElement = document.getElementById('selectedPlanName');
    const planPriceElement = document.getElementById('selectedPlanPrice');
    
    if (planNameElement) {
        planNameElement.textContent = `${planName.charAt(0).toUpperCase() + planName.slice(1)} Plan`;
    }
    
    if (planPriceElement) {
        planPriceElement.textContent = `$${price}/month`;
    }
    
    modal.classList.add('active');
    
    // Initialize Stripe Elements if not already done
    if (window.stripe && !window.stripeElementsInitialized) {
        initializeStripeElements();
    }
}

// Authentication status check
function checkAuthStatus() {
    // Check if user session exists
    fetch('/api/users/profile.php', {
        method: 'GET',
        credentials: 'include'
    })
    .then(response => {
        if (response.ok) {
            return response.json();
        }
        throw new Error('Not authenticated');
    })
    .then(data => {
        if (data.success) {
            currentUser = data.user;
            updateUIForAuthenticatedUser();
        }
    })
    .catch(error => {
        currentUser = null;
        updateUIForUnauthenticatedUser();
    });
}

function updateUIForAuthenticatedUser() {
    const navActions = document.querySelector('.nav-actions');
    if (navActions && currentUser) {
        navActions.innerHTML = `
            <div class="user-menu">
                <span class="user-name">Hello, ${currentUser.first_name || 'User'}</span>
                <button class="btn btn-secondary" onclick="showUserMenu()">
                    <i class="fas fa-user"></i>
                </button>
                <button class="btn btn-primary" onclick="window.location.href='dashboard.php'">
                    Dashboard
                </button>
            </div>
            <button class="mobile-menu-toggle">
                <i class="fas fa-bars"></i>
            </button>
        `;
        
        // Re-setup mobile menu after updating nav
        setupMobileMenu();
    }
}

function updateUIForUnauthenticatedUser() {
    const navActions = document.querySelector('.nav-actions');
    if (navActions) {
        navActions.innerHTML = `
            <button class="btn btn-secondary" onclick="showAuthModal('login')">
                Sign In
            </button>
            <button class="btn btn-primary" onclick="showAuthModal('signup')">
                Get Started
            </button>
            <button class="mobile-menu-toggle">
                <i class="fas fa-bars"></i>
            </button>
        `;
        
        // Re-setup mobile menu after updating nav
        setupMobileMenu();
    }
}

function showUserMenu() {
    const menuHtml = `
        <div class="user-menu-dropdown" style="
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(0, 0, 0, 0.5);
            z-index: 1003;
            display: flex;
            align-items: center;
            justify-content: center;
        ">
            <div class="user-menu-content" style="
                background: white;
                padding: 2rem;
                border-radius: 1rem;
                max-width: 24rem;
                width: 90%;
                box-shadow: 0 25px 50px rgba(0, 0, 0, 0.25);
            ">
                <h3 style="
                    font-size: 1.25rem;
                    font-weight: 600;
                    color: var(--foreground);
                    margin-bottom: 1.5rem;
                    text-align: center;
                ">Account Menu</h3>
                
                <div style="display: flex; flex-direction: column; gap: 0.75rem;">
                    <button onclick="window.location.href='dashboard.php'; closeUserMenu();" class="btn btn-secondary" style="width: 100%;">
                        <i class="fas fa-tachometer-alt" style="margin-right: 0.5rem;"></i>
                        Dashboard
                    </button>
                    <button onclick="showProfileModal(); closeUserMenu();" class="btn btn-secondary" style="width: 100%;">
                        <i class="fas fa-user" style="margin-right: 0.5rem;"></i>
                        Profile Settings
                    </button>
                    <button onclick="showSubscriptionModal(); closeUserMenu();" class="btn btn-secondary" style="width: 100%;">
                        <i class="fas fa-credit-card" style="margin-right: 0.5rem;"></i>
                        Subscription
                    </button>
                    <button onclick="logout(); closeUserMenu();" class="btn btn-secondary" style="width: 100%;">
                        <i class="fas fa-sign-out-alt" style="margin-right: 0.5rem;"></i>
                        Logout
                    </button>
                    <button onclick="closeUserMenu();" class="btn btn-outline-primary" style="width: 100%; margin-top: 0.5rem;">
                        Cancel
                    </button>
                </div>
            </div>
        </div>
    `;
    
    document.body.insertAdjacentHTML('beforeend', menuHtml);
}

function closeUserMenu() {
    const userMenu = document.querySelector('.user-menu-dropdown');
    if (userMenu) {
        userMenu.remove();
    }
}

function showProfileModal() {
    // Implementation for profile editing modal
    showNotification('Profile settings would open here', 'info');
}

function showSubscriptionModal() {
    // Implementation for subscription management modal
    showNotification('Subscription management would open here', 'info');
}

function logout() {
    fetch('/api/auth/logout.php', {
        method: 'POST',
        credentials: 'include'
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            currentUser = null;
            updateUIForUnauthenticatedUser();
            showNotification('You have been logged out successfully', 'success');
            
            // Redirect to home if on protected page
            if (window.location.pathname.includes('dashboard')) {
                window.location.href = 'index.php';
            }
        }
    })
    .catch(error => {
        console.error('Logout error:', error);
        // Force logout on client side even if server request fails
        currentUser = null;
        updateUIForUnauthenticatedUser();
        showNotification('You have been logged out', 'success');
        
        if (window.location.pathname.includes('dashboard')) {
            window.location.href = 'index.php';
        }
    });
}

function checkSessionTimeout() {
    if (currentUser) {
        fetch('/api/users/profile.php', {
            method: 'GET',
            credentials: 'include'
        })
        .then(response => {
            if (!response.ok) {
                throw new Error('Session expired');
            }
        })
        .catch(error => {
            showNotification('Your session has expired. Please log in again.', 'error');
            currentUser = null;
            updateUIForUnauthenticatedUser();
            
            if (window.location.pathname.includes('dashboard')) {
                window.location.href = 'index.php';
            }
        });
    }
}

// Utility functions
function showNotification(message, type = 'info') {
    const notification = document.createElement('div');
    notification.className = `notification ${type}`;
    notification.textContent = message;
    
    notification.style.cssText = `
        position: fixed;
        top: 20px;
        right: 20px;
        padding: 1rem 1.5rem;
        border-radius: 0.5rem;
        color: white;
        z-index: 1002;
        max-width: 300px;
        opacity: 0;
        transform: translateX(100%);
        transition: all 0.3s ease;
    `;
    
    if (type === 'success') {
        notification.style.backgroundColor = '#10b981';
    } else if (type === 'error') {
        notification.style.backgroundColor = '#ef4444';
    } else {
        notification.style.backgroundColor = '#3b82f6';
    }
    
    document.body.appendChild(notification);
    
    // Animate in
    setTimeout(() => {
        notification.style.opacity = '1';
        notification.style.transform = 'translateX(0)';
    }, 100);
    
    // Remove after 5 seconds
    setTimeout(() => {
        notification.style.opacity = '0';
        notification.style.transform = 'translateX(100%)';
        setTimeout(() => {
            if (notification.parentNode) {
                notification.parentNode.removeChild(notification);
            }
        }, 300);
    }, 5000);
}

function formatCurrency(amount) {
    return new Intl.NumberFormat('en-US', {
        style: 'currency',
        currency: 'USD'
    }).format(amount);
}

function validateEmail(email) {
    const re = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return re.test(email);
}

function validatePassword(password) {
    return password.length >= 8;
}

// Export functions for use in other scripts
window.HopeHarbor = {
    showAuthModal,
    switchAuthMode,
    closeModal,
    selectPlan,
    showServiceModal,
    showContactModal,
    scrollToSection,
    showNotification,
    logout
};
