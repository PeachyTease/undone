// Payment functionality for HopeHarbor using Stripe

// Initialize Stripe
let stripe, elements, cardNumber, cardExpiry, cardCvc;
let stripeElementsInitialized = false;

// Load Stripe configuration
document.addEventListener('DOMContentLoaded', function() {
    // Initialize Stripe with public key
    fetch('/api/config/stripe-key.php')
        .then(response => response.json())
        .then(data => {
            if (data.publishable_key) {
                stripe = Stripe(data.publishable_key);
            } else {
                console.error('Failed to load Stripe configuration');
            }
        })
        .catch(error => {
            console.error('Failed to load Stripe configuration:', error);
        });
});

function initializeStripeElements() {
    if (stripeElementsInitialized || !stripe) return;
    
    // Create Stripe Elements
    elements = stripe.elements();
    
    // Custom styling
    const style = {
        base: {
            fontSize: '16px',
            color: 'hsl(222.2, 84%, 4.9%)',
            fontFamily: 'Inter, system-ui, sans-serif',
            '::placeholder': {
                color: 'hsl(215.4, 16.3%, 46.9%)'
            }
        },
        invalid: {
            color: 'hsl(0, 84.2%, 60.2%)',
            iconColor: 'hsl(0, 84.2%, 60.2%)'
        }
    };
    
    // Create card elements
    cardNumber = elements.create('cardNumber', { style: style });
    cardExpiry = elements.create('cardExpiry', { style: style });
    cardCvc = elements.create('cardCvc', { style: style });
    
    // Mount elements
    cardNumber.mount('#card-number-element');
    cardExpiry.mount('#card-expiry-element');
    cardCvc.mount('#card-cvc-element');
    
    // Handle real-time validation errors
    cardNumber.on('change', handleStripeElementChange);
    cardExpiry.on('change', handleStripeElementChange);
    cardCvc.on('change', handleStripeElementChange);
    
    // Setup payment form
    const form = document.getElementById('payment-form');
    if (form) {
        form.addEventListener('submit', handlePaymentSubmit);
    }
    
    stripeElementsInitialized = true;
}

function handleStripeElementChange(event) {
    const displayError = document.getElementById('card-errors');
    if (event.error) {
        displayError.textContent = event.error.message;
    } else {
        displayError.textContent = '';
    }
}

async function handlePaymentSubmit(event) {
    event.preventDefault();
    
    if (!currentUser) {
        showNotification('Please log in to continue', 'error');
        closeModal('paymentModal');
        showAuthModal('login');
        return;
    }
    
    if (!window.selectedPlan) {
        showNotification('No plan selected', 'error');
        return;
    }
    
    const cardholderName = document.getElementById('cardholder-name').value;
    
    if (!cardholderName.trim()) {
        showPaymentError('Please enter the cardholder name');
        return;
    }
    
    // Show loading state
    setPaymentLoading(true);
    
    try {
        // Create payment method
        const {error, paymentMethod} = await stripe.createPaymentMethod({
            type: 'card',
            card: cardNumber,
            billing_details: {
                name: cardholderName,
                email: currentUser.email,
            },
        });
        
        if (error) {
            showPaymentError(error.message);
            setPaymentLoading(false);
            return;
        }
        
        // Send to backend to create subscription
        const response = await fetch('/api/payments/create_checkout.php', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            credentials: 'include',
            body: JSON.stringify({
                payment_method_id: paymentMethod.id,
                plan: window.selectedPlan.name,
                cardholder_name: cardholderName
            })
        });
        
        const data = await response.json();
        
        if (data.success) {
            // Handle successful subscription creation
            handleSuccessfulPayment(data);
        } else if (data.requires_action) {
            // Handle 3D Secure authentication
            handlePaymentRequiresAction(data);
        } else {
            showPaymentError(data.error || 'Payment failed');
        }
        
    } catch (error) {
        console.error('Payment error:', error);
        showPaymentError('An error occurred while processing your payment');
    } finally {
        setPaymentLoading(false);
    }
}

async function handlePaymentRequiresAction(data) {
    const {error, paymentIntent} = await stripe.confirmCardPayment(
        data.payment_intent.client_secret
    );
    
    if (error) {
        showPaymentError(error.message);
    } else {
        // Confirm payment with backend
        const response = await fetch('/api/payments/confirm_payment.php', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            credentials: 'include',
            body: JSON.stringify({
                payment_intent_id: paymentIntent.id
            })
        });
        
        const data = await response.json();
        if (data.success) {
            handleSuccessfulPayment(data);
        } else {
            showPaymentError(data.error || 'Payment confirmation failed');
        }
    }
}

function handleSuccessfulPayment(data) {
    // Update current user subscription info
    currentUser.subscription_plan = window.selectedPlan.name;
    currentUser.subscription_status = data.subscription ? data.subscription.status : 'active';
    
    // Close payment modal
    closeModal('paymentModal');
    
    // Show success message
    showSubscriptionSuccessModal(data.subscription || {
        plan: window.selectedPlan.name,
        status: 'active',
        trial_end: Math.floor(Date.now() / 1000) + (7 * 24 * 60 * 60) // 7 days from now
    });
    
    // Update UI
    updateUIForAuthenticatedUser();
}

function setPaymentLoading(loading) {
    const submitButton = document.getElementById('submit-payment');
    const buttonText = document.getElementById('button-text');
    const spinner = document.getElementById('spinner');
    
    if (loading) {
        submitButton.disabled = true;
        buttonText.style.display = 'none';
        spinner.style.display = 'inline-block';
    } else {
        submitButton.disabled = false;
        buttonText.style.display = 'inline';
        spinner.style.display = 'none';
    }
}

function showPaymentError(message) {
    const errorElement = document.getElementById('card-errors');
    if (errorElement) {
        errorElement.textContent = message;
    }
    
    // Also show as notification
    showNotification(message, 'error');
}

function showSubscriptionSuccessModal(subscription) {
    const successHtml = `
        <div class="success-overlay" style="
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(0, 0, 0, 0.8);
            z-index: 1003;
            display: flex;
            align-items: center;
            justify-content: center;
        ">
            <div class="success-content" style="
                background: white;
                padding: 2rem;
                border-radius: 1rem;
                max-width: 32rem;
                width: 90%;
                text-align: center;
                box-shadow: 0 25px 50px rgba(0, 0, 0, 0.25);
            ">
                <div style="
                    width: 4rem;
                    height: 4rem;
                    background: #10b981;
                    border-radius: 50%;
                    display: flex;
                    align-items: center;
                    justify-content: center;
                    margin: 0 auto 1.5rem;
                ">
                    <i class="fas fa-check" style="color: white; font-size: 1.5rem;"></i>
                </div>
                
                <h3 style="
                    font-size: 1.5rem;
                    font-weight: 700;
                    color: var(--foreground);
                    margin-bottom: 1rem;
                ">Subscription Activated!</h3>
                
                <p style="
                    color: var(--muted-foreground);
                    margin-bottom: 1.5rem;
                    line-height: 1.6;
                ">Your ${window.selectedPlan.name} plan subscription has been successfully activated. Your 7-day free trial starts now!</p>
                
                <div style="
                    background: var(--muted);
                    padding: 1rem;
                    border-radius: 0.5rem;
                    margin-bottom: 2rem;
                ">
                    <div style="
                        display: grid;
                        grid-template-columns: 1fr 1fr;
                        gap: 1rem;
                        text-align: left;
                    ">
                        <div>
                            <strong>Plan:</strong><br>
                            ${window.selectedPlan.name.charAt(0).toUpperCase() + window.selectedPlan.name.slice(1)}
                        </div>
                        <div>
                            <strong>Price:</strong><br>
                            $${window.selectedPlan.price}/month
                        </div>
                        <div>
                            <strong>Trial Ends:</strong><br>
                            ${formatTrialEndDate(subscription.trial_end)}
                        </div>
                        <div>
                            <strong>Status:</strong><br>
                            <span style="color: #10b981;">Active (Trial)</span>
                        </div>
                    </div>
                </div>
                
                <div style="display: flex; gap: 1rem; justify-content: center;">
                    <button onclick="closeSuccessMessage(); window.location.href='dashboard.php';" class="btn btn-primary">
                        Go to Dashboard
                    </button>
                    <button onclick="closeSuccessMessage();" class="btn btn-secondary">
                        Continue Browsing
                    </button>
                </div>
                
                <p style="
                    font-size: 0.875rem;
                    color: var(--muted-foreground);
                    margin-top: 1rem;
                ">You will be charged $${window.selectedPlan.price} after your trial ends. Cancel anytime.</p>
            </div>
        </div>
    `;
    
    document.body.insertAdjacentHTML('beforeend', successHtml);
}

function closeSuccessMessage() {
    const successOverlay = document.querySelector('.success-overlay');
    if (successOverlay) {
        successOverlay.remove();
    }
}

function formatTrialEndDate(timestamp) {
    if (!timestamp) return 'N/A';
    
    const date = new Date(timestamp * 1000); // Convert from Unix timestamp
    return date.toLocaleDateString('en-US', {
        year: 'numeric',
        month: 'short',
        day: 'numeric'
    });
}

// Subscription management functions
async function cancelSubscription() {
    if (!confirm('Are you sure you want to cancel your subscription? You will lose access to premium features at the end of your current billing period.')) {
        return;
    }
    
    try {
        const response = await fetch('/api/payments/cancel_subscription.php', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            credentials: 'include'
        });
        
        const data = await response.json();
        
        if (data.success) {
            showNotification('Subscription canceled successfully', 'success');
            // Update user status
            currentUser.subscription_status = 'canceled';
            updateUIForAuthenticatedUser();
        } else {
            showNotification(data.error || 'Failed to cancel subscription', 'error');
        }
        
    } catch (error) {
        console.error('Cancel subscription error:', error);
        showNotification('An error occurred while canceling subscription', 'error');
    }
}

async function updatePaymentMethod() {
    showNotification('Payment method update functionality would be implemented here', 'info');
}

// Promo code functionality
async function applyPromoCode(code) {
    if (!code || !code.trim()) {
        showNotification('Please enter a promo code', 'error');
        return;
    }
    
    try {
        const response = await fetch('/api/payments/apply_promo.php', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            credentials: 'include',
            body: JSON.stringify({
                code: code.trim()
            })
        });
        
        const data = await response.json();
        
        if (data.success) {
            showNotification(`Promo code applied! ${data.discount}% off your subscription`, 'success');
            // Update pricing display
            updatePricingWithDiscount(data.discount);
        } else {
            showNotification(data.error || 'Invalid promo code', 'error');
        }
        
    } catch (error) {
        console.error('Promo code error:', error);
        showNotification('An error occurred while applying promo code', 'error');
    }
}

function updatePricingWithDiscount(discount) {
    // Update the pricing display to show discounted amount
    const priceElement = document.getElementById('selectedPlanPrice');
    if (priceElement && window.selectedPlan) {
        const originalPrice = window.selectedPlan.price;
        const discountedPrice = originalPrice * (1 - discount / 100);
        
        priceElement.innerHTML = `
            <span style="text-decoration: line-through; color: var(--muted-foreground);">
                $${originalPrice}/month
            </span>
            <span style="color: #10b981; font-weight: bold;">
                $${discountedPrice.toFixed(2)}/month
            </span>
        `;
    }
}

// Export payment functions
window.PaymentManager = {
    initializeStripeElements,
    cancelSubscription,
    updatePaymentMethod,
    applyPromoCode
};
