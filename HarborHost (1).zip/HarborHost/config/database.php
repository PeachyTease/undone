<?php
// Database configuration for GoDaddy MySQL
class Database {
    private $host = 'localhost'; // GoDaddy default
    private $db_name = 'hopeharbor_db'; // Your database name
    private $username = ''; // Your database username
    private $password = ''; // Your database password
    private $conn;

    public function getConnection() {
        $this->conn = null;

        try {
            // Get database credentials from environment (PostgreSQL for testing, MySQL for production)
            $host = $_ENV['PGHOST'] ?? $_ENV['DB_HOST'] ?? $this->host;
            $db_name = $_ENV['PGDATABASE'] ?? $_ENV['DB_NAME'] ?? $this->db_name;
            $username = $_ENV['PGUSER'] ?? $_ENV['DB_USERNAME'] ?? $this->username;
            $password = $_ENV['PGPASSWORD'] ?? $_ENV['DB_PASSWORD'] ?? $this->password;
            // Determine database type and set appropriate defaults
            $isPostgreSQL = !empty($_ENV['PGHOST']);
            $port = $isPostgreSQL ? ($_ENV['PGPORT'] ?? '5432') : '3306';

            // Build DSN based on database type
            if ($isPostgreSQL) {
                $dsn = "pgsql:host=" . $host . ";port=" . $port . ";dbname=" . $db_name;
                $options = [
                    PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
                    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
                    PDO::ATTR_EMULATE_PREPARES => false
                ];
            } else {
                $dsn = "mysql:host=" . $host . ";dbname=" . $db_name . ";charset=utf8mb4";
                $options = [
                    PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
                    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
                    PDO::ATTR_EMULATE_PREPARES => false,
                    PDO::MYSQL_ATTR_INIT_COMMAND => "SET NAMES utf8mb4"
                ];
            }

            $this->conn = new PDO($dsn, $username, $password, $options);
        } catch(PDOException $exception) {
            error_log("Connection error: " . $exception->getMessage());
            throw new Exception("Database connection failed");
        }

        return $this->conn;
    }
}
?>
