<?php
// Stripe configuration
class StripeConfig {
    public static function getPublishableKey() {
        return $_ENV['STRIPE_PUBLISHABLE_KEY'] ?? 'pk_test_your_publishable_key_here';
    }

    public static function getSecretKey() {
        $key = $_ENV['STRIPE_SECRET_KEY'] ?? 'sk_test_your_secret_key_here';
        if ($key === 'sk_test_your_secret_key_here') {
            error_log('WARNING: Using default Stripe secret key. Set STRIPE_SECRET_KEY environment variable.');
        }
        return $key;
    }

    public static function getWebhookSecret() {
        return $_ENV['STRIPE_WEBHOOK_SECRET'] ?? 'whsec_your_webhook_secret_here';
    }

    public static function getPriceIds() {
        return [
            'basic' => $_ENV['STRIPE_BASIC_PRICE_ID'] ?? 'price_basic_monthly',
            'premium' => $_ENV['STRIPE_PREMIUM_PRICE_ID'] ?? 'price_premium_monthly', 
            'professional' => $_ENV['STRIPE_PROFESSIONAL_PRICE_ID'] ?? 'price_professional_monthly'
        ];
    }

    public static function getSuccessUrl() {
        $base_url = $_ENV['BASE_URL'] ?? 'https://yoursite.com';
        return $base_url . '/dashboard.php?payment=success';
    }

    public static function getCancelUrl() {
        $base_url = $_ENV['BASE_URL'] ?? 'https://yoursite.com';
        return $base_url . '/pricing.php?payment=canceled';
    }
}

// Return Stripe publishable key for frontend if accessed directly
if (basename($_SERVER['PHP_SELF']) === 'stripe.php') {
    header('Content-Type: application/json');
    echo json_encode([
        'publishable_key' => StripeConfig::getPublishableKey()
    ]);
    exit;
}
?>
