<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Contact Us - HopeHarbor</title>
    <meta name="description" content="Get in touch with HopeHarbor for support, consultations, or questions about our mental health services. We're here to help.">
    
    <!-- Fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
    
    <!-- Styles -->
    <link rel="stylesheet" href="assets/css/styles.css">
</head>

<body>
    <?php include 'includes/header.php'; ?>

    <!-- Hero Section -->
    <section class="hero-section">
        <div class="container">
            <div class="hero-content" style="text-align: center; max-width: 48rem; margin: 0 auto;">
                <h1 class="hero-title" data-testid="text-contact-hero-title">
                    Get in Touch
                </h1>
                <p class="hero-description" data-testid="text-contact-hero-description">
                    Have questions about our services? Need support? Want to schedule a consultation? We're here to help you on your mental health journey.
                </p>
            </div>
        </div>
    </section>

    <!-- Contact Section -->
    <section class="contact-section">
        <div class="container">
            <div class="contact-grid">
                <!-- Contact Information -->
                <div class="contact-info">
                    <h2 class="contact-info-title" data-testid="text-contact-info-title">Let's Connect</h2>
                    <p class="contact-info-description" data-testid="text-contact-info-description">
                        Our team is ready to support you. Choose the best way to reach us below.
                    </p>

                    <div class="contact-methods">
                        <div class="contact-method" data-testid="contact-crisis">
                            <div class="contact-method-icon crisis-icon">
                                <i class="fas fa-phone"></i>
                            </div>
                            <div class="contact-method-content">
                                <h3>Crisis Support</h3>
                                <p>Immediate help available 24/7</p>
                                <button class="btn btn-primary" onclick="accessCrisisSupport()" data-testid="button-crisis-support">
                                    Get Help Now
                                </button>
                            </div>
                        </div>

                        <div class="contact-method" data-testid="contact-general">
                            <div class="contact-method-icon">
                                <i class="fas fa-envelope"></i>
                            </div>
                            <div class="contact-method-content">
                                <h3>General Support</h3>
                                <p>Questions about services or billing</p>
                                <a href="mailto:support@hopeharbor.com" class="contact-link" data-testid="link-email-support">
                                    support@hopeharbor.com
                                </a>
                            </div>
                        </div>

                        <div class="contact-method" data-testid="contact-consultation">
                            <div class="contact-method-icon">
                                <i class="fas fa-calendar"></i>
                            </div>
                            <div class="contact-method-content">
                                <h3>Free Consultation</h3>
                                <p>15-minute chat with our team</p>
                                <button class="btn btn-secondary" onclick="showConsultationModal()" data-testid="button-schedule-consultation">
                                    Schedule Now
                                </button>
                            </div>
                        </div>

                        <div class="contact-method" data-testid="contact-phone">
                            <div class="contact-method-icon">
                                <i class="fas fa-phone-alt"></i>
                            </div>
                            <div class="contact-method-content">
                                <h3>Phone Support</h3>
                                <p>Mon-Fri, 9 AM - 6 PM EST</p>
                                <a href="tel:+1-800-HOPE-123" class="contact-link" data-testid="link-phone-support">
                                    1-800-HOPE-123
                                </a>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Contact Form -->
                <div class="contact-form-container">
                    <div class="contact-form-card">
                        <h3 class="contact-form-title" data-testid="text-form-title">Send us a Message</h3>
                        <p class="contact-form-description" data-testid="text-form-description">
                            Fill out the form below and we'll get back to you within 24 hours.
                        </p>

                        <form class="contact-form" onsubmit="handleContactForm(event)" data-testid="form-contact">
                            <div class="form-row">
                                <div class="form-group">
                                    <label>First Name</label>
                                    <input type="text" name="firstName" data-testid="input-first-name" required>
                                </div>
                                <div class="form-group">
                                    <label>Last Name</label>
                                    <input type="text" name="lastName" data-testid="input-last-name" required>
                                </div>
                            </div>

                            <div class="form-group">
                                <label>Email Address</label>
                                <input type="email" name="email" data-testid="input-email" required>
                            </div>

                            <div class="form-group">
                                <label>Phone Number (Optional)</label>
                                <input type="tel" name="phone" data-testid="input-phone">
                            </div>

                            <div class="form-group">
                                <label>How can we help you?</label>
                                <select name="subject" data-testid="select-subject" required>
                                    <option value="">Select a topic</option>
                                    <option value="general">General Questions</option>
                                    <option value="services">Services Information</option>
                                    <option value="billing">Billing & Payments</option>
                                    <option value="technical">Technical Support</option>
                                    <option value="consultation">Free Consultation</option>
                                    <option value="partnership">Partnership Inquiries</option>
                                    <option value="other">Other</option>
                                </select>
                            </div>

                            <div class="form-group">
                                <label>Message</label>
                                <textarea name="message" rows="5" placeholder="Tell us how we can help you..." data-testid="input-message" required></textarea>
                            </div>

                            <div class="form-group">
                                <label class="checkbox-label">
                                    <input type="checkbox" name="newsletter" data-testid="input-newsletter">
                                    <span>I'd like to receive updates about mental health resources and tips</span>
                                </label>
                            </div>

                            <button type="submit" class="btn btn-primary btn-full" data-testid="button-submit-form">
                                Send Message
                            </button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- FAQ Section -->
    <section class="faq-section">
        <div class="container">
            <div class="section-header">
                <h2 class="section-title" data-testid="text-faq-title">Common Questions</h2>
                <p class="section-description" data-testid="text-faq-description">Quick answers to frequently asked questions</p>
            </div>
            
            <div class="faq-grid">
                <div class="faq-item" data-testid="faq-response-time">
                    <h3>How quickly will you respond?</h3>
                    <p>We typically respond to all inquiries within 24 hours during business days. For urgent matters, please use our crisis support line available 24/7.</p>
                </div>
                
                <div class="faq-item" data-testid="faq-consultation-free">
                    <h3>Is the consultation really free?</h3>
                    <p>Yes! Our 15-minute consultation is completely free with no obligations. It's designed to help you understand our services and determine if we're a good fit.</p>
                </div>
                
                <div class="faq-item" data-testid="faq-privacy">
                    <h3>Is my information private?</h3>
                    <p>Absolutely. All communications are confidential and protected under HIPAA regulations. We never share your personal information without your explicit consent.</p>
                </div>
                
                <div class="faq-item" data-testid="faq-emergency">
                    <h3>What if I have a mental health emergency?</h3>
                    <p>If you're experiencing a mental health emergency, please call 911 or go to your nearest emergency room. You can also call our 24/7 crisis support line for immediate assistance.</p>
                </div>
            </div>
        </div>
    </section>

    <!-- CTA Section -->
    <section class="cta-section">
        <div class="container">
            <div class="cta-content">
                <h2 class="cta-title" data-testid="text-cta-contact-title">Ready to Start Your Journey?</h2>
                <p class="cta-description" data-testid="text-cta-contact-description">
                    Don't wait to prioritize your mental health. Take the first step today with a free consultation or start your 7-day trial.
                </p>
                <div class="cta-actions">
                    <button class="btn btn-white" onclick="showConsultationModal()" data-testid="button-free-consultation">
                        Free Consultation
                    </button>
                    <button class="btn btn-outline-white" onclick="window.location.href='pricing.php'" data-testid="button-start-trial">
                        Start Free Trial
                    </button>
                </div>
                <p class="cta-note" data-testid="text-cta-contact-note">No credit card required • HIPAA compliant • Available 24/7</p>
            </div>
        </div>
    </section>

    <?php include 'includes/footer.php'; ?>

    <!-- Consultation Modal -->
    <div id="consultationModal" class="modal" data-testid="modal-consultation">
        <div class="modal-content">
            <div class="modal-header">
                <h3>Schedule Free Consultation</h3>
                <p>Book a 15-minute call with our mental health professionals</p>
                <button class="modal-close" onclick="closeModal('consultationModal')" data-testid="button-close-consultation">
                    <i class="fas fa-times"></i>
                </button>
            </div>
            
            <form onsubmit="handleConsultationForm(event)" data-testid="form-consultation">
                <div class="form-row">
                    <div class="form-group">
                        <label>First Name</label>
                        <input type="text" name="firstName" data-testid="input-consultation-firstname" required>
                    </div>
                    <div class="form-group">
                        <label>Last Name</label>
                        <input type="text" name="lastName" data-testid="input-consultation-lastname" required>
                    </div>
                </div>
                
                <div class="form-group">
                    <label>Email</label>
                    <input type="email" name="email" data-testid="input-consultation-email" required>
                </div>
                
                <div class="form-group">
                    <label>Phone Number</label>
                    <input type="tel" name="phone" data-testid="input-consultation-phone" required>
                </div>
                
                <div class="form-group">
                    <label>Preferred Day</label>
                    <select name="day" data-testid="select-consultation-day" required>
                        <option value="">Select a day</option>
                        <option value="monday">Monday</option>
                        <option value="tuesday">Tuesday</option>
                        <option value="wednesday">Wednesday</option>
                        <option value="thursday">Thursday</option>
                        <option value="friday">Friday</option>
                    </select>
                </div>
                
                <div class="form-group">
                    <label>Preferred Time</label>
                    <select name="time" data-testid="select-consultation-time" required>
                        <option value="">Select a time</option>
                        <option value="9am">9:00 AM</option>
                        <option value="10am">10:00 AM</option>
                        <option value="11am">11:00 AM</option>
                        <option value="1pm">1:00 PM</option>
                        <option value="2pm">2:00 PM</option>
                        <option value="3pm">3:00 PM</option>
                        <option value="4pm">4:00 PM</option>
                    </select>
                </div>
                
                <div class="form-group">
                    <label>What would you like to discuss? (Optional)</label>
                    <textarea name="topics" rows="3" placeholder="Let us know what you'd like to learn about..." data-testid="input-consultation-topics"></textarea>
                </div>
                
                <button type="submit" class="btn btn-primary btn-full" data-testid="button-schedule-submit">
                    Schedule Consultation
                </button>
            </form>
        </div>
    </div>

    <!-- Scripts -->
    <script src="assets/js/main.js"></script>
    <script src="assets/js/contact.js"></script>

    <style>
        .contact-section {
            padding: 5rem 0;
            background: var(--background);
        }

        .contact-grid {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 4rem;
            align-items: start;
        }

        .contact-info-title {
            font-size: 2rem;
            font-weight: 700;
            color: var(--foreground);
            margin-bottom: 1rem;
        }

        .contact-info-description {
            font-size: 1.125rem;
            color: var(--muted-foreground);
            margin-bottom: 3rem;
            line-height: 1.6;
        }

        .contact-methods {
            display: flex;
            flex-direction: column;
            gap: 2rem;
        }

        .contact-method {
            display: flex;
            align-items: center;
            gap: 1.5rem;
            padding: 1.5rem;
            background: var(--card);
            border-radius: var(--radius);
            border: 1px solid var(--border);
        }

        .contact-method-icon {
            width: 3rem;
            height: 3rem;
            background: var(--primary);
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            color: var(--primary-foreground);
            font-size: 1.25rem;
        }

        .crisis-icon {
            background: #ef4444;
            animation: pulse 2s infinite;
        }

        @keyframes pulse {
            0%, 100% { transform: scale(1); }
            50% { transform: scale(1.05); }
        }

        .contact-method-content h3 {
            font-size: 1.125rem;
            font-weight: 600;
            color: var(--foreground);
            margin-bottom: 0.5rem;
        }

        .contact-method-content p {
            color: var(--muted-foreground);
            margin-bottom: 1rem;
        }

        .contact-link {
            color: var(--primary);
            text-decoration: none;
            font-weight: 500;
        }

        .contact-link:hover {
            text-decoration: underline;
        }

        .contact-form-container {
            position: sticky;
            top: 2rem;
        }

        .contact-form-card {
            background: var(--card);
            border-radius: var(--radius);
            padding: 2rem;
            box-shadow: 0 10px 25px rgba(0, 0, 0, 0.1);
            border: 1px solid var(--border);
        }

        .contact-form-title {
            font-size: 1.5rem;
            font-weight: 700;
            color: var(--foreground);
            margin-bottom: 0.5rem;
        }

        .contact-form-description {
            color: var(--muted-foreground);
            margin-bottom: 2rem;
        }

        .faq-section {
            padding: 5rem 0;
            background: var(--muted);
        }

        .faq-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
            gap: 2rem;
            max-width: 64rem;
            margin: 0 auto;
        }

        .faq-item {
            background: var(--card);
            border-radius: var(--radius);
            padding: 2rem;
            box-shadow: 0 1px 3px rgba(0, 0, 0, 0.1);
            border: 1px solid var(--border);
        }

        .faq-item h3 {
            font-size: 1.125rem;
            font-weight: 600;
            color: var(--foreground);
            margin-bottom: 1rem;
        }

        .faq-item p {
            color: var(--muted-foreground);
            line-height: 1.6;
        }

        @media (max-width: 768px) {
            .contact-grid {
                grid-template-columns: 1fr;
                gap: 3rem;
            }

            .contact-form-container {
                position: static;
            }

            .contact-method {
                flex-direction: column;
                text-align: center;
            }
        }
    </style>
</body>
</html>
