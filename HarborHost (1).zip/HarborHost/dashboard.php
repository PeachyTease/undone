<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard - HopeHarbor</title>
    <meta name="description" content="Your personal mental health dashboard with access to therapists, support groups, and wellness tools.">
    
    <!-- Fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
    
    <!-- Styles -->
    <link rel="stylesheet" href="assets/css/styles.css">
</head>

<body>
    <?php 
    session_start();
    if (!isset($_SESSION['user_id'])) {
        header('Location: index.php');
        exit;
    }
    ?>

    <!-- Header -->
    <header class="header">
        <div class="container">
            <div class="header-content">
                <a href="index.php" class="logo" data-testid="link-logo">
                    <div class="logo-icon">
                        <i class="fas fa-anchor"></i>
                    </div>
                    <span class="logo-text">HopeHarbor</span>
                </a>
                
                <nav class="nav">
                    <ul class="nav-links">
                        <li><a href="services.php" class="nav-link" data-testid="link-services">Services</a></li>
                        <li><a href="pricing.php" class="nav-link" data-testid="link-pricing">Pricing</a></li>
                        <li><a href="contact.php" class="nav-link" data-testid="link-contact">Contact</a></li>
                    </ul>
                    
                    <div class="nav-actions">
                        <div class="user-menu">
                            <span class="user-name" data-testid="text-user-name">Welcome back!</span>
                            <button class="btn btn-secondary" onclick="showUserMenu()" data-testid="button-user-menu">
                                <i class="fas fa-user"></i>
                            </button>
                            <button class="btn btn-primary" onclick="logout()" data-testid="button-logout">
                                Logout
                            </button>
                        </div>
                        
                        <button class="mobile-menu-toggle" data-testid="button-mobile-menu">
                            <i class="fas fa-bars"></i>
                        </button>
                    </div>
                </nav>
            </div>
        </div>
        
        <!-- Mobile Navigation -->
        <div class="mobile-nav" data-testid="nav-mobile">
            <ul class="mobile-nav-links">
                <li><a href="services.php" class="nav-link">Services</a></li>
                <li><a href="pricing.php" class="nav-link">Pricing</a></li>
                <li><a href="contact.php" class="nav-link">Contact</a></li>
            </ul>
        </div>
    </header>

    <!-- Dashboard Content -->
    <main class="dashboard-container">
        <div class="container">
            <div class="dashboard-header">
                <h1 class="dashboard-title" data-testid="text-dashboard-title">Your Mental Health Dashboard</h1>
                <p class="dashboard-subtitle" data-testid="text-dashboard-subtitle">Track your progress and access your mental health resources</p>
            </div>

            <!-- Quick Actions -->
            <div class="dashboard-grid">
                <div class="dashboard-card" data-testid="card-schedule-session">
                    <h3><i class="fas fa-calendar-plus"></i> Schedule Session</h3>
                    <p>Book your next therapy session with a licensed professional</p>
                    <button class="btn btn-primary" onclick="scheduleSession()" data-testid="button-schedule-session">
                        Schedule Now
                    </button>
                </div>

                <div class="dashboard-card" data-testid="card-support-groups">
                    <h3><i class="fas fa-users"></i> Support Groups</h3>
                    <p>Join ongoing support groups and connect with peers</p>
                    <button class="btn btn-primary" onclick="viewSupportGroups()" data-testid="button-view-groups">
                        View Groups
                    </button>
                </div>

                <div class="dashboard-card" data-testid="card-wellness-tools">
                    <h3><i class="fas fa-brain"></i> Wellness Tools</h3>
                    <p>Access guided meditations, mood tracking, and coping strategies</p>
                    <button class="btn btn-primary" onclick="openWellnessTools()" data-testid="button-wellness-tools">
                        Open Tools
                    </button>
                </div>

                <div class="dashboard-card" data-testid="card-crisis-support">
                    <h3><i class="fas fa-phone"></i> Crisis Support</h3>
                    <p>Get immediate help when you need it most</p>
                    <button class="btn btn-primary" onclick="accessCrisisSupport()" data-testid="button-crisis-support">
                        Get Help Now
                    </button>
                </div>

                <div class="dashboard-card" data-testid="card-resource-library">
                    <h3><i class="fas fa-book-open"></i> Resource Library</h3>
                    <p>Browse articles, worksheets, and educational content</p>
                    <button class="btn btn-primary" onclick="browseResources()" data-testid="button-browse-resources">
                        Browse Library
                    </button>
                </div>

                <div class="dashboard-card" data-testid="card-subscription">
                    <h3><i class="fas fa-credit-card"></i> Subscription</h3>
                    <p>Manage your subscription and billing information</p>
                    <button class="btn btn-primary" onclick="manageSubscription()" data-testid="button-manage-subscription">
                        Manage Plan
                    </button>
                </div>
            </div>

            <!-- Recent Activity -->
            <section style="margin-top: 3rem;">
                <h2 class="section-title" data-testid="text-recent-title">Recent Activity</h2>
                <div class="dashboard-card">
                    <div id="recentActivity" data-testid="container-recent-activity">
                        <p class="text-muted-foreground">Loading your recent activity...</p>
                    </div>
                </div>
            </section>

            <!-- Progress Tracking -->
            <section style="margin-top: 3rem;">
                <h2 class="section-title" data-testid="text-progress-title">Your Progress</h2>
                <div class="dashboard-grid">
                    <div class="dashboard-card" data-testid="card-sessions-count">
                        <h3>Therapy Sessions</h3>
                        <div style="font-size: 2rem; font-weight: bold; color: var(--primary); margin: 1rem 0;" id="sessionsCount" data-testid="text-sessions-count">-</div>
                        <p>Total sessions completed</p>
                    </div>

                    <div class="dashboard-card" data-testid="card-groups-joined">
                        <h3>Support Groups</h3>
                        <div style="font-size: 2rem; font-weight: bold; color: var(--primary); margin: 1rem 0;" id="groupsCount" data-testid="text-groups-count">-</div>
                        <p>Groups you've joined</p>
                    </div>

                    <div class="dashboard-card" data-testid="card-tools-used">
                        <h3>Wellness Tools</h3>
                        <div style="font-size: 2rem; font-weight: bold; color: var(--primary); margin: 1rem 0;" id="toolsCount" data-testid="text-tools-count">-</div>
                        <p>Tools accessed this month</p>
                    </div>
                </div>
            </section>
        </div>
    </main>

    <!-- Footer -->
    <footer class="footer">
        <div class="container">
            <div class="footer-content">
                <div class="footer-company">
                    <div class="footer-logo">
                        <div class="footer-logo-icon">
                            <i class="fas fa-anchor"></i>
                        </div>
                        <span class="footer-logo-text">HopeHarbor</span>
                    </div>
                    <p class="footer-description">
                        Providing accessible, compassionate mental health care through innovative technology and evidence-based practices.
                    </p>
                </div>
                
                <div class="footer-section">
                    <h3>Quick Links</h3>
                    <ul class="footer-links">
                        <li><a href="services.php">Services</a></li>
                        <li><a href="pricing.php">Pricing</a></li>
                        <li><a href="contact.php">Contact</a></li>
                        <li><a href="#" onclick="accessCrisisSupport()">Crisis Support</a></li>
                    </ul>
                </div>
                
                <div class="footer-section">
                    <h3>Account</h3>
                    <ul class="footer-links">
                        <li><a href="#" onclick="manageSubscription()">Subscription</a></li>
                        <li><a href="#" onclick="showProfileModal()">Profile Settings</a></li>
                        <li><a href="#" onclick="logout()">Logout</a></li>
                    </ul>
                </div>
            </div>
            
            <div class="footer-bottom">
                <div class="footer-copyright">
                    © 2024 HopeHarbor. All rights reserved.
                </div>
                <div class="footer-legal">
                    <a href="#">Privacy Policy</a>
                    <a href="#">Terms of Service</a>
                    <a href="#">HIPAA Notice</a>
                </div>
            </div>
        </div>
    </footer>

    <!-- Scripts -->
    <script src="assets/js/main.js"></script>
    <script src="assets/js/dashboard.js"></script>
</body>
</html>
