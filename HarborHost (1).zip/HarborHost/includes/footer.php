<footer class="footer">
    <div class="container">
        <div class="footer-content">
            <div class="footer-company">
                <div class="footer-logo">
                    <div class="footer-logo-icon">
                        <i class="fas fa-anchor"></i>
                    </div>
                    <span class="footer-logo-text">HopeHarbor</span>
                </div>
                <p class="footer-description">
                    Providing accessible, compassionate mental health care through innovative technology and evidence-based practices.
                </p>
                <div class="footer-social">
                    <a href="#" aria-label="Facebook" data-testid="link-facebook">
                        <i class="fab fa-facebook-f"></i>
                    </a>
                    <a href="#" aria-label="Twitter" data-testid="link-twitter">
                        <i class="fab fa-twitter"></i>
                    </a>
                    <a href="#" aria-label="LinkedIn" data-testid="link-linkedin">
                        <i class="fab fa-linkedin-in"></i>
                    </a>
                    <a href="#" aria-label="Instagram" data-testid="link-instagram">
                        <i class="fab fa-instagram"></i>
                    </a>
                </div>
            </div>
            
            <div class="footer-section">
                <h3>Services</h3>
                <ul class="footer-links">
                    <li><a href="services.php" data-testid="footer-link-telehealth">Telehealth Sessions</a></li>
                    <li><a href="services.php" data-testid="footer-link-groups">Support Groups</a></li>
                    <li><a href="services.php" data-testid="footer-link-crisis">Crisis Support</a></li>
                    <li><a href="services.php" data-testid="footer-link-tools">Wellness Tools</a></li>
                    <li><a href="services.php" data-testid="footer-link-family">Family Support</a></li>
                </ul>
            </div>
            
            <div class="footer-section">
                <h3>Company</h3>
                <ul class="footer-links">
                    <li><a href="#" data-testid="footer-link-about">About Us</a></li>
                    <li><a href="#" data-testid="footer-link-team">Our Team</a></li>
                    <li><a href="#" data-testid="footer-link-careers">Careers</a></li>
                    <li><a href="#" data-testid="footer-link-press">Press</a></li>
                    <li><a href="contact.php" data-testid="footer-link-contact">Contact</a></li>
                </ul>
            </div>
        </div>
        
        <div class="footer-bottom">
            <div class="footer-copyright">
                © <?php echo date('Y'); ?> HopeHarbor. All rights reserved.
            </div>
            <div class="footer-legal">
                <a href="#" data-testid="footer-link-privacy">Privacy Policy</a>
                <a href="#" data-testid="footer-link-terms">Terms of Service</a>
                <a href="#" data-testid="footer-link-hipaa">HIPAA Notice</a>
            </div>
        </div>
    </div>
</footer>
