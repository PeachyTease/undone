<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
$isLoggedIn = isset($_SESSION['user_id']);
$userName = $isLoggedIn ? ($_SESSION['user_name'] ?? 'User') : '';
?>

<header class="header">
    <div class="container">
        <div class="header-content">
            <a href="index.php" class="logo" data-testid="link-logo">
                <div class="logo-icon">
                    <i class="fas fa-anchor"></i>
                </div>
                <span class="logo-text">HopeHarbor</span>
            </a>
            
            <nav class="nav">
                <ul class="nav-links">
                    <li><a href="services.php" class="nav-link" data-testid="link-services">Services</a></li>
                    <li><a href="pricing.php" class="nav-link" data-testid="link-pricing">Pricing</a></li>
                    <li><a href="contact.php" class="nav-link" data-testid="link-contact">Contact</a></li>
                </ul>
                
                <div class="nav-actions">
                    <?php if ($isLoggedIn): ?>
                        <div class="user-menu">
                            <span class="user-name" data-testid="text-user-name">Hello, <?php echo htmlspecialchars(explode(' ', $userName)[0]); ?></span>
                            <button class="btn btn-secondary" onclick="showUserMenu()" data-testid="button-user-menu">
                                <i class="fas fa-user"></i>
                            </button>
                            <button class="btn btn-primary" onclick="window.location.href='dashboard.php'" data-testid="button-dashboard">
                                Dashboard
                            </button>
                        </div>
                    <?php else: ?>
                        <button class="btn btn-secondary" onclick="showAuthModal('login')" data-testid="button-signin">
                            Sign In
                        </button>
                        <button class="btn btn-primary" onclick="showAuthModal('signup')" data-testid="button-get-started">
                            Get Started
                        </button>
                    <?php endif; ?>
                    
                    <button class="mobile-menu-toggle" data-testid="button-mobile-menu">
                        <i class="fas fa-bars"></i>
                    </button>
                </div>
            </nav>
        </div>
    </div>
    
    <!-- Mobile Navigation -->
    <div class="mobile-nav" data-testid="nav-mobile">
        <ul class="mobile-nav-links">
            <li><a href="services.php" class="nav-link">Services</a></li>
            <li><a href="pricing.php" class="nav-link">Pricing</a></li>
            <li><a href="contact.php" class="nav-link">Contact</a></li>
            <?php if ($isLoggedIn): ?>
                <li><a href="dashboard.php" class="nav-link">Dashboard</a></li>
                <li><a href="#" onclick="logout()" class="nav-link">Logout</a></li>
            <?php else: ?>
                <li><a href="#" onclick="showAuthModal('login')" class="nav-link">Sign In</a></li>
                <li><a href="#" onclick="showAuthModal('signup')" class="nav-link">Get Started</a></li>
            <?php endif; ?>
        </ul>
    </div>
</header>
