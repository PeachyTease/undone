<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>HopeHarbor - Your Safe Space for Growth and Support</title>
    <meta name="description" content="Connect with licensed professionals, join supportive communities, and access personalized resources on your journey to mental wellness.">
    
    <!-- Open Graph tags -->
    <meta property="og:title" content="HopeHarbor - Your Safe Space for Growth and Support">
    <meta property="og:description" content="Connect with licensed professionals, join supportive communities, and access personalized resources on your journey to mental wellness.">
    <meta property="og:type" content="website">
    <meta property="og:url" content="https://yoursite.com">
    <meta property="og:image" content="https://yoursite.com/assets/images/og-image.jpg">
    
    <!-- Fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
    
    <!-- Styles -->
    <link rel="stylesheet" href="assets/css/styles.css">
</head>

<body>
    <?php include 'includes/header.php'; ?>

    <!-- Hero Section -->
    <section class="hero-section">
        <div class="container">
            <div class="hero-grid">
                <div class="hero-content">
                    <h1 class="hero-title">
                        Your Safe Space for
                        <span class="hero-highlight">Growth & Support</span>
                    </h1>
                    <p class="hero-description">
                        Connect with licensed professionals, join supportive communities, and access personalized resources on your journey to mental wellness.
                    </p>
                    <div class="hero-actions">
                        <button class="btn btn-white" data-testid="button-start-journey" onclick="showAuthModal('signup')">
                            Start Your Journey
                        </button>
                        <button class="btn btn-outline-white" data-testid="button-learn-more" onclick="scrollToSection('services')">
                            Learn More
                        </button>
                    </div>
                </div>
                
                <div class="hero-image">
                    <img src="https://images.unsplash.com/photo-1506905925346-21bda4d32df4?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=800&h=600" alt="Peaceful mountain lake reflecting hope and serenity" data-testid="img-hero" />
                    
                    <!-- Trust Indicators -->
                    <div class="trust-indicator trust-indicator-top" data-testid="indicator-hipaa">
                        <i class="fas fa-shield-alt"></i>
                        <div>
                            <div class="trust-title">HIPAA Compliant</div>
                            <div class="trust-subtitle">Secure & Private</div>
                        </div>
                    </div>
                    
                    <div class="trust-indicator trust-indicator-bottom" data-testid="indicator-users">
                        <i class="fas fa-users"></i>
                        <div>
                            <div class="trust-title">10,000+</div>
                            <div class="trust-subtitle">Lives Transformed</div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Services Section -->
    <section id="services" class="services-section">
        <div class="container">
            <div class="section-header">
                <h2 class="section-title" data-testid="text-services-title">Comprehensive Support for Your Mental Health</h2>
                <p class="section-description" data-testid="text-services-description">Our platform offers a range of evidence-based services to support your mental wellness journey.</p>
            </div>
            
            <div class="services-grid">
                <div class="service-card" data-testid="card-service-telehealth">
                    <div class="service-icon">
                        <i class="fas fa-video"></i>
                    </div>
                    <h3 class="service-title">Telehealth Sessions</h3>
                    <p class="service-description">Connect with licensed therapists and counselors through secure video sessions from the comfort of your home.</p>
                    <button class="service-link" data-testid="link-learn-telehealth" onclick="showServiceModal('telehealth')">
                        Learn More <i class="fas fa-arrow-right"></i>
                    </button>
                </div>
                
                <div class="service-card" data-testid="card-service-groups">
                    <div class="service-icon service-icon-cyan">
                        <i class="fas fa-users"></i>
                    </div>
                    <h3 class="service-title">Support Groups</h3>
                    <p class="service-description">Join facilitated group sessions with peers who understand your journey and challenges.</p>
                    <button class="service-link" data-testid="link-learn-groups" onclick="showServiceModal('groups')">
                        Learn More <i class="fas fa-arrow-right"></i>
                    </button>
                </div>
                
                <div class="service-card" data-testid="card-service-tools">
                    <div class="service-icon service-icon-green">
                        <i class="fas fa-brain"></i>
                    </div>
                    <h3 class="service-title">Wellness Tools</h3>
                    <p class="service-description">Access guided meditations, mood tracking, and personalized coping strategies.</p>
                    <button class="service-link" data-testid="link-learn-tools" onclick="showServiceModal('tools')">
                        Learn More <i class="fas fa-arrow-right"></i>
                    </button>
                </div>
                
                <div class="service-card" data-testid="card-service-crisis">
                    <div class="service-icon service-icon-purple">
                        <i class="fas fa-clock"></i>
                    </div>
                    <h3 class="service-title">24/7 Crisis Support</h3>
                    <p class="service-description">Immediate access to crisis counselors when you need support the most.</p>
                    <button class="service-link" data-testid="link-learn-crisis" onclick="showServiceModal('crisis')">
                        Learn More <i class="fas fa-arrow-right"></i>
                    </button>
                </div>
                
                <div class="service-card" data-testid="card-service-resources">
                    <div class="service-icon service-icon-orange">
                        <i class="fas fa-book-open"></i>
                    </div>
                    <h3 class="service-title">Resource Library</h3>
                    <p class="service-description">Explore articles, worksheets, and educational content curated by mental health experts.</p>
                    <button class="service-link" data-testid="link-learn-resources" onclick="showServiceModal('resources')">
                        Learn More <i class="fas fa-arrow-right"></i>
                    </button>
                </div>
                
                <div class="service-card" data-testid="card-service-family">
                    <div class="service-icon service-icon-pink">
                        <i class="fas fa-heart"></i>
                    </div>
                    <h3 class="service-title">Family Support</h3>
                    <p class="service-description">Specialized programs for families and loved ones affected by mental health challenges.</p>
                    <button class="service-link" data-testid="link-learn-family" onclick="showServiceModal('family')">
                        Learn More <i class="fas fa-arrow-right"></i>
                    </button>
                </div>
            </div>
        </div>
    </section>

    <!-- Pricing Section -->
    <section id="pricing" class="pricing-section">
        <div class="container">
            <div class="section-header">
                <h2 class="section-title" data-testid="text-pricing-title">Affordable Plans for Everyone</h2>
                <p class="section-description" data-testid="text-pricing-description">Choose a plan that works for your needs and budget. All plans include our core support features.</p>
            </div>
            
            <div class="pricing-grid">
                <!-- Basic Plan -->
                <div class="pricing-card" data-testid="card-plan-basic">
                    <div class="pricing-header">
                        <h3 class="pricing-plan">Basic</h3>
                        <div class="pricing-price" data-testid="text-price-basic">$29<span>/month</span></div>
                        <p class="pricing-subtitle">Perfect for getting started</p>
                    </div>
                    
                    <ul class="pricing-features">
                        <li><i class="fas fa-check"></i> 2 therapy sessions per month</li>
                        <li><i class="fas fa-check"></i> Access to support groups</li>
                        <li><i class="fas fa-check"></i> Wellness tools & resources</li>
                        <li><i class="fas fa-check"></i> Mobile app access</li>
                    </ul>
                    
                    <button class="btn btn-secondary" data-testid="button-select-basic" onclick="selectPlan('basic', 29)">
                        Choose Basic
                    </button>
                </div>
                
                <!-- Premium Plan -->
                <div class="pricing-card pricing-card-popular" data-testid="card-plan-premium">
                    <div class="pricing-badge">Most Popular</div>
                    
                    <div class="pricing-header">
                        <h3 class="pricing-plan">Premium</h3>
                        <div class="pricing-price" data-testid="text-price-premium">$79<span>/month</span></div>
                        <p class="pricing-subtitle">Comprehensive support</p>
                    </div>
                    
                    <ul class="pricing-features">
                        <li><i class="fas fa-check"></i> Unlimited therapy sessions</li>
                        <li><i class="fas fa-check"></i> Priority scheduling</li>
                        <li><i class="fas fa-check"></i> 24/7 crisis support</li>
                        <li><i class="fas fa-check"></i> Family therapy included</li>
                        <li><i class="fas fa-check"></i> Personalized care plan</li>
                    </ul>
                    
                    <button class="btn btn-primary" data-testid="button-select-premium" onclick="selectPlan('premium', 79)">
                        Choose Premium
                    </button>
                </div>
                
                <!-- Professional Plan -->
                <div class="pricing-card" data-testid="card-plan-professional">
                    <div class="pricing-header">
                        <h3 class="pricing-plan">Professional</h3>
                        <div class="pricing-price" data-testid="text-price-professional">$149<span>/month</span></div>
                        <p class="pricing-subtitle">For businesses & organizations</p>
                    </div>
                    
                    <ul class="pricing-features">
                        <li><i class="fas fa-check"></i> Everything in Premium</li>
                        <li><i class="fas fa-check"></i> Employee assistance program</li>
                        <li><i class="fas fa-check"></i> Workplace wellness training</li>
                        <li><i class="fas fa-check"></i> Analytics & reporting</li>
                        <li><i class="fas fa-check"></i> Dedicated account manager</li>
                    </ul>
                    
                    <button class="btn btn-secondary" data-testid="button-select-professional" onclick="selectPlan('professional', 149)">
                        Choose Professional
                    </button>
                </div>
            </div>
            
            <div class="pricing-footer">
                <p class="pricing-note" data-testid="text-trial-info">All plans include a 7-day free trial. Cancel anytime.</p>
                <div class="pricing-badges">
                    <div class="pricing-badge-item" data-testid="badge-hipaa">
                        <i class="fas fa-shield-alt"></i>
                        <span>HIPAA Compliant</span>
                    </div>
                    <div class="pricing-badge-item" data-testid="badge-secure">
                        <i class="fas fa-lock"></i>
                        <span>Secure Payments</span>
                    </div>
                    <div class="pricing-badge-item" data-testid="badge-support">
                        <i class="fas fa-phone"></i>
                        <span>24/7 Support</span>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Testimonials Section -->
    <section class="testimonials-section">
        <div class="container">
            <div class="section-header">
                <h2 class="section-title" data-testid="text-testimonials-title">Trusted by Thousands</h2>
                <p class="section-description" data-testid="text-testimonials-description">Real stories from people who found hope and healing through our platform.</p>
            </div>
            
            <div class="testimonials-grid">
                <div class="testimonial-card" data-testid="card-testimonial-1">
                    <div class="testimonial-rating">
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                    </div>
                    <p class="testimonial-text">
                        "HopeHarbor changed my life. The therapists are incredibly skilled and the platform makes it so easy to get help when I need it most."
                    </p>
                    <div class="testimonial-author">
                        <img src="https://images.unsplash.com/photo-1494790108755-2616b612b786?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=150&h=150" alt="Sarah Chen" data-testid="img-avatar-sarah" />
                        <div>
                            <div class="author-name" data-testid="text-author-sarah">Sarah Chen</div>
                            <div class="author-title">Marketing Manager</div>
                        </div>
                    </div>
                </div>
                
                <div class="testimonial-card" data-testid="card-testimonial-2">
                    <div class="testimonial-rating">
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                    </div>
                    <p class="testimonial-text">
                        "The support groups helped me realize I wasn't alone. The community here is incredibly supportive and understanding."
                    </p>
                    <div class="testimonial-author">
                        <img src="https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=150&h=150" alt="Michael Rodriguez" data-testid="img-avatar-michael" />
                        <div>
                            <div class="author-name" data-testid="text-author-michael">Michael Rodriguez</div>
                            <div class="author-title">Teacher</div>
                        </div>
                    </div>
                </div>
                
                <div class="testimonial-card" data-testid="card-testimonial-3">
                    <div class="testimonial-rating">
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                    </div>
                    <p class="testimonial-text">
                        "As a busy parent, the flexibility of telehealth sessions was a game-changer. I can finally prioritize my mental health."
                    </p>
                    <div class="testimonial-author">
                        <img src="https://images.unsplash.com/photo-1438761681033-6461ffad8d80?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=150&h=150" alt="Jessica Thompson" data-testid="img-avatar-jessica" />
                        <div>
                            <div class="author-name" data-testid="text-author-jessica">Jessica Thompson</div>
                            <div class="author-title">Working Parent</div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- CTA Section -->
    <section class="cta-section">
        <div class="container">
            <div class="cta-content">
                <h2 class="cta-title" data-testid="text-cta-title">Ready to Start Your Healing Journey?</h2>
                <p class="cta-description" data-testid="text-cta-description">
                    Join thousands of people who have found hope, healing, and community through HopeHarbor. Your mental health matters, and help is just a click away.
                </p>
                <div class="cta-actions">
                    <button class="btn btn-white" data-testid="button-start-trial" onclick="selectPlan('premium', 79)">
                        Start Free Trial
                    </button>
                    <button class="btn btn-outline-white" data-testid="button-schedule-consultation" onclick="showContactModal()">
                        Schedule Consultation
                    </button>
                </div>
                <p class="cta-note" data-testid="text-cta-note">No credit card required • 7-day free trial • Cancel anytime</p>
            </div>
        </div>
    </section>

    <?php include 'includes/footer.php'; ?>

    <!-- Auth Modal -->
    <div id="authModal" class="modal" data-testid="modal-auth">
        <div class="modal-content">
            <div class="modal-header">
                <h3 id="authModalTitle">Welcome Back</h3>
                <p id="authModalSubtitle">Sign in to your HopeHarbor account</p>
                <button class="modal-close" data-testid="button-close-auth" onclick="closeModal('authModal')">
                    <i class="fas fa-times"></i>
                </button>
            </div>
            
            <div id="loginForm" class="auth-form">
                <form onsubmit="handleLogin(event)">
                    <div class="form-group">
                        <label>Email</label>
                        <input type="email" name="email" data-testid="input-login-email" required>
                    </div>
                    <div class="form-group">
                        <label>Password</label>
                        <input type="password" name="password" data-testid="input-login-password" required>
                    </div>
                    <div class="form-row">
                        <label class="checkbox-label">
                            <input type="checkbox" name="remember" data-testid="input-remember-me">
                            <span>Remember me</span>
                        </label>
                        <a href="#" class="forgot-link" data-testid="link-forgot-password">Forgot password?</a>
                    </div>
                    <button type="submit" class="btn btn-primary btn-full" data-testid="button-login-submit">Sign In</button>
                </form>
                <div class="auth-switch">
                    <p>Don't have an account? <button onclick="switchAuthMode('signup')" data-testid="button-switch-signup">Sign up</button></p>
                </div>
            </div>
            
            <div id="signupForm" class="auth-form" style="display: none;">
                <form onsubmit="handleSignup(event)">
                    <div class="form-row">
                        <div class="form-group">
                            <label>First Name</label>
                            <input type="text" name="firstName" data-testid="input-signup-firstname" required>
                        </div>
                        <div class="form-group">
                            <label>Last Name</label>
                            <input type="text" name="lastName" data-testid="input-signup-lastname" required>
                        </div>
                    </div>
                    <div class="form-group">
                        <label>Email</label>
                        <input type="email" name="email" data-testid="input-signup-email" required>
                    </div>
                    <div class="form-group">
                        <label>Password</label>
                        <input type="password" name="password" data-testid="input-signup-password" required>
                    </div>
                    <div class="form-group">
                        <label class="checkbox-label">
                            <input type="checkbox" name="terms" data-testid="input-agree-terms" required>
                            <span>I agree to the <a href="#" data-testid="link-terms">Terms of Service</a> and <a href="#" data-testid="link-privacy">Privacy Policy</a></span>
                        </label>
                    </div>
                    <button type="submit" class="btn btn-primary btn-full" data-testid="button-signup-submit">Create Account</button>
                </form>
                <div class="auth-switch">
                    <p>Already have an account? <button onclick="switchAuthMode('login')" data-testid="button-switch-login">Sign in</button></p>
                </div>
            </div>
        </div>
    </div>

    <!-- Payment Modal -->
    <div id="paymentModal" class="modal" data-testid="modal-payment">
        <div class="modal-content modal-content-wide">
            <div class="modal-header">
                <h3 id="paymentModalTitle">Complete Your Subscription</h3>
                <button class="modal-close" data-testid="button-close-payment" onclick="closeModal('paymentModal')">
                    <i class="fas fa-times"></i>
                </button>
            </div>
            
            <div class="payment-content">
                <div class="payment-summary">
                    <h4>Selected Plan</h4>
                    <div class="plan-details">
                        <div class="plan-name" id="selectedPlanName" data-testid="text-selected-plan">Premium Plan</div>
                        <div class="plan-price" id="selectedPlanPrice" data-testid="text-selected-price">$79/month</div>
                    </div>
                    <div class="trial-info">
                        <i class="fas fa-gift"></i>
                        <span>7-day free trial included</span>
                    </div>
                </div>
                
                <div class="payment-form">
                    <h4>Payment Information</h4>
                    <form id="payment-form">
                        <div class="form-group">
                            <label>Card Number</label>
                            <div id="card-number-element" class="stripe-element" data-testid="input-card-number"></div>
                        </div>
                        <div class="form-row">
                            <div class="form-group">
                                <label>Expiry Date</label>
                                <div id="card-expiry-element" class="stripe-element" data-testid="input-card-expiry"></div>
                            </div>
                            <div class="form-group">
                                <label>CVC</label>
                                <div id="card-cvc-element" class="stripe-element" data-testid="input-card-cvc"></div>
                            </div>
                        </div>
                        <div class="form-group">
                            <label>Cardholder Name</label>
                            <input type="text" id="cardholder-name" data-testid="input-cardholder-name" required>
                        </div>
                        
                        <div id="card-errors" role="alert" class="error-message" data-testid="text-card-errors"></div>
                        
                        <button type="submit" id="submit-payment" class="btn btn-primary btn-full" data-testid="button-submit-payment">
                            <span id="button-text">Start 7-Day Free Trial</span>
                            <div id="spinner" class="spinner" style="display: none;"></div>
                        </button>
                    </form>
                </div>
            </div>
        </div>
    </div>

    <!-- Scripts -->
    <script src="https://js.stripe.com/v3/"></script>
    <script src="assets/js/main.js"></script>
    <script src="assets/js/auth.js"></script>
    <script src="assets/js/payment.js"></script>
</body>
</html>
