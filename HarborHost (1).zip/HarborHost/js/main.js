// Main JavaScript functionality for HopeHarbor

// Global variables
let currentUser = null;
let mobileMenuOpen = false;

// Initialize the application
document.addEventListener('DOMContentLoaded', function() {
    initializeApp();
    setupEventListeners();
    checkAuthStatus();
});

function initializeApp() {
    // Set up smooth scrolling
    setupSmoothScrolling();
    
    // Initialize mobile menu
    setupMobileMenu();
    
    // Check for authentication status
    checkAuthStatus();
}

function setupEventListeners() {
    // Modal backdrop clicks
    document.addEventListener('click', function(e) {
        if (e.target.classList.contains('modal')) {
            closeModal(e.target.id);
        }
    });

    // Escape key to close modals
    document.addEventListener('keydown', function(e) {
        if (e.key === 'Escape') {
            closeAllModals();
        }
    });

    // Session timeout check
    setInterval(checkSessionTimeout, 60000); // Check every minute
}

function setupSmoothScrolling() {
    document.querySelectorAll('a[href^="#"]').forEach(anchor => {
        anchor.addEventListener('click', function (e) {
            e.preventDefault();
            const target = document.querySelector(this.getAttribute('href'));
            if (target) {
                target.scrollIntoView({
                    behavior: 'smooth',
                    block: 'start'
                });
            }
        });
    });
}

function setupMobileMenu() {
    const toggle = document.querySelector('.mobile-menu-toggle');
    const mobileNav = document.querySelector('.mobile-nav');
    
    if (toggle && mobileNav) {
        toggle.addEventListener('click', function() {
            mobileMenuOpen = !mobileMenuOpen;
            mobileNav.classList.toggle('active', mobileMenuOpen);
            
            // Update icon
            const icon = toggle.querySelector('i');
            if (icon) {
                icon.className = mobileMenuOpen ? 'fas fa-times' : 'fas fa-bars';
            }
        });
    }
}

function scrollToSection(sectionId) {
    const element = document.getElementById(sectionId);
    if (element) {
        element.scrollIntoView({
            behavior: 'smooth',
            block: 'start'
        });
    }
}

// Modal functions
function showAuthModal(mode = 'login') {
    const modal = document.getElementById('authModal');
    const loginForm = document.getElementById('loginForm');
    const signupForm = document.getElementById('signupForm');
    const title = document.getElementById('authModalTitle');
    const subtitle = document.getElementById('authModalSubtitle');
    
    if (mode === 'login') {
        loginForm.style.display = 'block';
        signupForm.style.display = 'none';
        title.textContent = 'Welcome Back';
        subtitle.textContent = 'Sign in to your HopeHarbor account';
    } else {
        loginForm.style.display = 'none';
        signupForm.style.display = 'block';
        title.textContent = 'Join HopeHarbor';
        subtitle.textContent = 'Start your journey to better mental health';
    }
    
    modal.classList.add('active');
    
    // Focus first input
    setTimeout(() => {
        const firstInput = modal.querySelector('input[type="email"]');
        if (firstInput) firstInput.focus();
    }, 100);
}

function switchAuthMode(mode) {
    showAuthModal(mode);
}

function closeModal(modalId) {
    const modal = document.getElementById(modalId);
    if (modal) {
        modal.classList.remove('active');
        
        // Clear form data
        const forms = modal.querySelectorAll('form');
        forms.forEach(form => form.reset());
        
        // Clear error messages
        const errors = modal.querySelectorAll('.error-message');
        errors.forEach(error => error.textContent = '');
    }
}

function closeAllModals() {
    const modals = document.querySelectorAll('.modal');
    modals.forEach(modal => {
        modal.classList.remove('active');
    });
}

function showServiceModal(serviceType) {
    // In a real implementation, this would show detailed information
    // about the specific service
    alert(`Learn more about ${serviceType} service. This would open a detailed modal in the full implementation.`);
}

function showContactModal() {
    alert('Contact modal would open here. This would include a contact form in the full implementation.');
}

// Plan selection
function selectPlan(planName, price) {
    if (!currentUser) {
        showAuthModal('signup');
        return;
    }
    
    // Store selected plan details
    window.selectedPlan = {
        name: planName,
        price: price
    };
    
    // Show payment modal
    showPaymentModal(planName, price);
}

function showPaymentModal(planName, price) {
    const modal = document.getElementById('paymentModal');
    const planNameElement = document.getElementById('selectedPlanName');
    const planPriceElement = document.getElementById('selectedPlanPrice');
    
    if (planNameElement) {
        planNameElement.textContent = `${planName.charAt(0).toUpperCase() + planName.slice(1)} Plan`;
    }
    
    if (planPriceElement) {
        planPriceElement.textContent = `$${price}/month`;
    }
    
    modal.classList.add('active');
    
    // Initialize Stripe Elements if not already done
    if (window.stripe && !window.stripeElementsInitialized) {
        initializeStripeElements();
    }
}

// Authentication status check
function checkAuthStatus() {
    // Check if user session exists
    fetch('/api/user.php', {
        method: 'GET',
        credentials: 'include'
    })
    .then(response => {
        if (response.ok) {
            return response.json();
        }
        throw new Error('Not authenticated');
    })
    .then(data => {
        if (data.success) {
            currentUser = data.user;
            updateUIForAuthenticatedUser();
        }
    })
    .catch(error => {
        currentUser = null;
        updateUIForUnauthenticatedUser();
    });
}

function updateUIForAuthenticatedUser() {
    const navActions = document.querySelector('.nav-actions');
    if (navActions && currentUser) {
        navActions.innerHTML = `
            <div class="user-menu">
                <span class="user-name">Hello, ${currentUser.first_name || 'User'}</span>
                <button class="btn btn-secondary" onclick="showUserMenu()">
                    <i class="fas fa-user"></i>
                </button>
                <button class="btn btn-primary" onclick="window.location.href='dashboard/'">
                    Dashboard
                </button>
            </div>
        `;
    }
}

function updateUIForUnauthenticatedUser() {
    const navActions = document.querySelector('.nav-actions');
    if (navActions) {
        navActions.innerHTML = `
            <button class="btn btn-secondary" onclick="showAuthModal('login')">
                Sign In
            </button>
            <button class="btn btn-primary" onclick="showAuthModal('signup')">
                Get Started
            </button>
            <button class="mobile-menu-toggle">
                <i class="fas fa-bars"></i>
            </button>
        `;
        
        // Re-setup mobile menu after updating nav
        setupMobileMenu();
    }
}

function showUserMenu() {
    // Simple user menu - in full implementation this would be a dropdown
    const options = [
        'View Profile',
        'Subscription Settings', 
        'Logout'
    ];
    
    const choice = prompt('Select an option:\n1. View Profile\n2. Subscription Settings\n3. Logout');
    
    switch(choice) {
        case '1':
            window.location.href = 'dashboard/';
            break;
        case '2':
            alert('Subscription settings would open here');
            break;
        case '3':
            logout();
            break;
    }
}

function logout() {
    fetch('/auth/logout.php', {
        method: 'POST',
        credentials: 'include'
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            currentUser = null;
            updateUIForUnauthenticatedUser();
            window.location.reload();
        }
    })
    .catch(error => {
        console.error('Logout error:', error);
        // Force logout on client side even if server request fails
        currentUser = null;
        updateUIForUnauthenticatedUser();
        window.location.reload();
    });
}

function checkSessionTimeout() {
    if (currentUser) {
        fetch('/api/user.php', {
            method: 'GET',
            credentials: 'include'
        })
        .then(response => {
            if (!response.ok) {
                throw new Error('Session expired');
            }
        })
        .catch(error => {
            alert('Your session has expired. Please log in again.');
            currentUser = null;
            updateUIForUnauthenticatedUser();
            window.location.reload();
        });
    }
}

// Utility functions
function showNotification(message, type = 'info') {
    // Simple notification system - could be enhanced with a proper toast library
    const notification = document.createElement('div');
    notification.className = `notification notification-${type}`;
    notification.textContent = message;
    
    notification.style.cssText = `
        position: fixed;
        top: 20px;
        right: 20px;
        padding: 1rem 1.5rem;
        border-radius: 0.5rem;
        color: white;
        z-index: 1002;
        max-width: 300px;
        opacity: 0;
        transform: translateX(100%);
        transition: all 0.3s ease;
    `;
    
    if (type === 'success') {
        notification.style.backgroundColor = '#10b981';
    } else if (type === 'error') {
        notification.style.backgroundColor = '#ef4444';
    } else {
        notification.style.backgroundColor = '#3b82f6';
    }
    
    document.body.appendChild(notification);
    
    // Animate in
    setTimeout(() => {
        notification.style.opacity = '1';
        notification.style.transform = 'translateX(0)';
    }, 100);
    
    // Remove after 5 seconds
    setTimeout(() => {
        notification.style.opacity = '0';
        notification.style.transform = 'translateX(100%)';
        setTimeout(() => {
            if (notification.parentNode) {
                notification.parentNode.removeChild(notification);
            }
        }, 300);
    }, 5000);
}

function formatCurrency(amount) {
    return new Intl.NumberFormat('en-US', {
        style: 'currency',
        currency: 'USD'
    }).format(amount);
}

function validateEmail(email) {
    const re = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return re.test(email);
}

function validatePassword(password) {
    return password.length >= 8;
}

// Export functions for use in other scripts
window.HopeHarbor = {
    showAuthModal,
    switchAuthMode,
    closeModal,
    selectPlan,
    showServiceModal,
    showContactModal,
    scrollToSection,
    showNotification,
    logout
};
