<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Pricing - HopeHarbor</title>
    <meta name="description" content="Affordable mental health plans starting at $29/month. Choose from Basic, Premium, or Professional plans with 7-day free trial.">
    
    <!-- Fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
    
    <!-- Styles -->
    <link rel="stylesheet" href="assets/css/styles.css">
</head>

<body>
    <?php include 'includes/header.php'; ?>

    <!-- Hero Section -->
    <section class="hero-section">
        <div class="container">
            <div class="hero-content" style="text-align: center; max-width: 48rem; margin: 0 auto;">
                <h1 class="hero-title" data-testid="text-pricing-hero-title">
                    Affordable Plans for Everyone
                </h1>
                <p class="hero-description" data-testid="text-pricing-hero-description">
                    Choose a plan that works for your needs and budget. All plans include our core support features with a 7-day free trial.
                </p>
                <p class="hero-note" style="font-size: 1rem; color: hsl(210, 100%, 85%); margin-top: 1rem;" data-testid="text-trial-note">
                    <i class="fas fa-gift"></i> Start with a 7-day free trial • No credit card required
                </p>
            </div>
        </div>
    </section>

    <!-- Pricing Section -->
    <section class="pricing-section">
        <div class="container">
            <div class="pricing-grid">
                <!-- Basic Plan -->
                <div class="pricing-card" data-testid="card-plan-basic">
                    <div class="pricing-header">
                        <h3 class="pricing-plan">Basic</h3>
                        <div class="pricing-price" data-testid="text-price-basic">$29<span>/month</span></div>
                        <p class="pricing-subtitle">Perfect for getting started</p>
                    </div>
                    
                    <ul class="pricing-features">
                        <li><i class="fas fa-check"></i> 2 therapy sessions per month</li>
                        <li><i class="fas fa-check"></i> Access to support groups</li>
                        <li><i class="fas fa-check"></i> Wellness tools & resources</li>
                        <li><i class="fas fa-check"></i> Mobile app access</li>
                        <li><i class="fas fa-check"></i> Resource library</li>
                        <li><i class="fas fa-check"></i> Community forums</li>
                    </ul>
                    
                    <button class="btn btn-secondary btn-full" data-testid="button-select-basic" onclick="selectPlan('basic', 29)">
                        Start Free Trial
                    </button>
                    
                    <p class="pricing-trial-note">7-day free trial, then $29/month</p>
                </div>
                
                <!-- Premium Plan (Popular) -->
                <div class="pricing-card pricing-card-popular" data-testid="card-plan-premium">
                    <div class="pricing-badge">Most Popular</div>
                    
                    <div class="pricing-header">
                        <h3 class="pricing-plan">Premium</h3>
                        <div class="pricing-price" data-testid="text-price-premium">$79<span>/month</span></div>
                        <p class="pricing-subtitle">Comprehensive support</p>
                    </div>
                    
                    <ul class="pricing-features">
                        <li><i class="fas fa-check"></i> Unlimited therapy sessions</li>
                        <li><i class="fas fa-check"></i> Priority scheduling</li>
                        <li><i class="fas fa-check"></i> 24/7 crisis support</li>
                        <li><i class="fas fa-check"></i> Family therapy included</li>
                        <li><i class="fas fa-check"></i> Personalized care plan</li>
                        <li><i class="fas fa-check"></i> Progress tracking & insights</li>
                        <li><i class="fas fa-check"></i> Premium wellness tools</li>
                        <li><i class="fas fa-check"></i> Everything in Basic</li>
                    </ul>
                    
                    <button class="btn btn-primary btn-full" data-testid="button-select-premium" onclick="selectPlan('premium', 79)">
                        Start Free Trial
                    </button>
                    
                    <p class="pricing-trial-note">7-day free trial, then $79/month</p>
                </div>
                
                <!-- Professional Plan -->
                <div class="pricing-card" data-testid="card-plan-professional">
                    <div class="pricing-header">
                        <h3 class="pricing-plan">Professional</h3>
                        <div class="pricing-price" data-testid="text-price-professional">$149<span>/month</span></div>
                        <p class="pricing-subtitle">For businesses & organizations</p>
                    </div>
                    
                    <ul class="pricing-features">
                        <li><i class="fas fa-check"></i> Everything in Premium</li>
                        <li><i class="fas fa-check"></i> Employee assistance program</li>
                        <li><i class="fas fa-check"></i> Workplace wellness training</li>
                        <li><i class="fas fa-check"></i> Analytics & reporting</li>
                        <li><i class="fas fa-check"></i> Dedicated account manager</li>
                        <li><i class="fas fa-check"></i> Custom integrations</li>
                        <li><i class="fas fa-check"></i> Bulk user management</li>
                    </ul>
                    
                    <button class="btn btn-secondary btn-full" data-testid="button-select-professional" onclick="selectPlan('professional', 149)">
                        Contact Sales
                    </button>
                    
                    <p class="pricing-trial-note">Custom pricing available</p>
                </div>
            </div>
            
            <div class="pricing-footer">
                <p class="pricing-note" data-testid="text-trial-info">All plans include a 7-day free trial. Cancel anytime with no hidden fees.</p>
                <div class="pricing-badges">
                    <div class="pricing-badge-item" data-testid="badge-hipaa">
                        <i class="fas fa-shield-alt"></i>
                        <span>HIPAA Compliant</span>
                    </div>
                    <div class="pricing-badge-item" data-testid="badge-secure">
                        <i class="fas fa-lock"></i>
                        <span>Secure Payments</span>
                    </div>
                    <div class="pricing-badge-item" data-testid="badge-support">
                        <i class="fas fa-phone"></i>
                        <span>24/7 Support</span>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- FAQ Section -->
    <section class="faq-section">
        <div class="container">
            <div class="section-header">
                <h2 class="section-title" data-testid="text-faq-title">Frequently Asked Questions</h2>
                <p class="section-description" data-testid="text-faq-description">Get answers to common questions about our pricing and services</p>
            </div>
            
            <div class="faq-grid">
                <div class="faq-item" data-testid="faq-trial">
                    <h3>How does the free trial work?</h3>
                    <p>You get full access to all features of your chosen plan for 7 days, completely free. No credit card required to start. You can cancel anytime during the trial period.</p>
                </div>
                
                <div class="faq-item" data-testid="faq-cancel">
                    <h3>Can I cancel anytime?</h3>
                    <p>Yes, you can cancel your subscription at any time from your dashboard. There are no cancellation fees or hidden charges. You'll retain access until the end of your current billing period.</p>
                </div>
                
                <div class="faq-item" data-testid="faq-change-plan">
                    <h3>Can I change my plan later?</h3>
                    <p>Absolutely! You can upgrade or downgrade your plan at any time. Changes take effect at your next billing cycle, and we'll prorate any differences.</p>
                </div>
                
                <div class="faq-item" data-testid="faq-insurance">
                    <h3>Do you accept insurance?</h3>
                    <p>We're working on insurance integration. Currently, our plans are designed to be affordable alternatives to traditional therapy, often costing less than typical insurance copays.</p>
                </div>
                
                <div class="faq-item" data-testid="faq-therapists">
                    <h3>Are your therapists licensed?</h3>
                    <p>Yes, all our therapists are licensed mental health professionals with specialized training in telehealth delivery. They're credentialed in their respective states.</p>
                </div>
                
                <div class="faq-item" data-testid="faq-data-security">
                    <h3>How secure is my data?</h3>
                    <p>We use bank-level encryption and are fully HIPAA compliant. Your personal information and session data are protected with the highest security standards.</p>
                </div>
            </div>
        </div>
    </section>

    <!-- CTA Section -->
    <section class="cta-section">
        <div class="container">
            <div class="cta-content">
                <h2 class="cta-title" data-testid="text-cta-pricing-title">Ready to Invest in Your Mental Health?</h2>
                <p class="cta-description" data-testid="text-cta-pricing-description">
                    Join thousands who have transformed their lives with HopeHarbor. Start your free trial today and experience the difference.
                </p>
                <div class="cta-actions">
                    <button class="btn btn-white" onclick="selectPlan('premium', 79)" data-testid="button-start-trial-cta">
                        Start Free Trial
                    </button>
                    <button class="btn btn-outline-white" onclick="showContactModal()" data-testid="button-contact-sales">
                        Contact Sales
                    </button>
                </div>
                <p class="cta-note" data-testid="text-cta-pricing-note">No credit card required • Cancel anytime • HIPAA compliant</p>
            </div>
        </div>
    </section>

    <?php include 'includes/footer.php'; ?>

    <!-- Auth Modal -->
    <div id="authModal" class="modal" data-testid="modal-auth">
        <div class="modal-content">
            <div class="modal-header">
                <h3 id="authModalTitle">Join HopeHarbor</h3>
                <p id="authModalSubtitle">Start your mental health journey today</p>
                <button class="modal-close" data-testid="button-close-auth" onclick="closeModal('authModal')">
                    <i class="fas fa-times"></i>
                </button>
            </div>
            
            <div id="loginForm" class="auth-form" style="display: none;">
                <form onsubmit="handleLogin(event)">
                    <div class="form-group">
                        <label>Email</label>
                        <input type="email" name="email" data-testid="input-login-email" required>
                    </div>
                    <div class="form-group">
                        <label>Password</label>
                        <input type="password" name="password" data-testid="input-login-password" required>
                    </div>
                    <div class="form-row">
                        <label class="checkbox-label">
                            <input type="checkbox" name="remember" data-testid="input-remember-me">
                            <span>Remember me</span>
                        </label>
                        <a href="#" class="forgot-link" data-testid="link-forgot-password">Forgot password?</a>
                    </div>
                    <button type="submit" class="btn btn-primary btn-full" data-testid="button-login-submit">Sign In</button>
                </form>
                <div class="auth-switch">
                    <p>Don't have an account? <button onclick="switchAuthMode('signup')" data-testid="button-switch-signup">Sign up</button></p>
                </div>
            </div>
            
            <div id="signupForm" class="auth-form">
                <form onsubmit="handleSignup(event)">
                    <div class="form-row">
                        <div class="form-group">
                            <label>First Name</label>
                            <input type="text" name="firstName" data-testid="input-signup-firstname" required>
                        </div>
                        <div class="form-group">
                            <label>Last Name</label>
                            <input type="text" name="lastName" data-testid="input-signup-lastname" required>
                        </div>
                    </div>
                    <div class="form-group">
                        <label>Email</label>
                        <input type="email" name="email" data-testid="input-signup-email" required>
                    </div>
                    <div class="form-group">
                        <label>Password</label>
                        <input type="password" name="password" data-testid="input-signup-password" required>
                    </div>
                    <div class="form-group">
                        <label class="checkbox-label">
                            <input type="checkbox" name="terms" data-testid="input-agree-terms" required>
                            <span>I agree to the <a href="#" data-testid="link-terms">Terms of Service</a> and <a href="#" data-testid="link-privacy">Privacy Policy</a></span>
                        </label>
                    </div>
                    <button type="submit" class="btn btn-primary btn-full" data-testid="button-signup-submit">Start Free Trial</button>
                </form>
                <div class="auth-switch">
                    <p>Already have an account? <button onclick="switchAuthMode('login')" data-testid="button-switch-login">Sign in</button></p>
                </div>
            </div>
        </div>
    </div>

    <!-- Payment Modal -->
    <div id="paymentModal" class="modal" data-testid="modal-payment">
        <div class="modal-content modal-content-wide">
            <div class="modal-header">
                <h3 id="paymentModalTitle">Complete Your Subscription</h3>
                <button class="modal-close" data-testid="button-close-payment" onclick="closeModal('paymentModal')">
                    <i class="fas fa-times"></i>
                </button>
            </div>
            
            <div class="payment-content">
                <div class="payment-summary">
                    <h4>Selected Plan</h4>
                    <div class="plan-details">
                        <div class="plan-name" id="selectedPlanName" data-testid="text-selected-plan">Premium Plan</div>
                        <div class="plan-price" id="selectedPlanPrice" data-testid="text-selected-price">$79/month</div>
                    </div>
                    <div class="trial-info">
                        <i class="fas fa-gift"></i>
                        <span>7-day free trial included</span>
                    </div>
                </div>
                
                <div class="payment-form">
                    <h4>Payment Information</h4>
                    <form id="payment-form">
                        <div class="form-group">
                            <label>Card Number</label>
                            <div id="card-number-element" class="stripe-element" data-testid="input-card-number"></div>
                        </div>
                        <div class="form-row">
                            <div class="form-group">
                                <label>Expiry Date</label>
                                <div id="card-expiry-element" class="stripe-element" data-testid="input-card-expiry"></div>
                            </div>
                            <div class="form-group">
                                <label>CVC</label>
                                <div id="card-cvc-element" class="stripe-element" data-testid="input-card-cvc"></div>
                            </div>
                        </div>
                        <div class="form-group">
                            <label>Cardholder Name</label>
                            <input type="text" id="cardholder-name" data-testid="input-cardholder-name" required>
                        </div>
                        
                        <div id="card-errors" role="alert" class="error-message" data-testid="text-card-errors"></div>
                        
                        <button type="submit" id="submit-payment" class="btn btn-primary btn-full" data-testid="button-submit-payment">
                            <span id="button-text">Start 7-Day Free Trial</span>
                            <div id="spinner" class="spinner" style="display: none;"></div>
                        </button>
                    </form>
                </div>
            </div>
        </div>
    </div>

    <!-- Scripts -->
    <script src="https://js.stripe.com/v3/"></script>
    <script src="assets/js/main.js"></script>
    <script src="assets/js/auth.js"></script>
    <script src="assets/js/payment.js"></script>

    <style>
        .pricing-trial-note {
            text-align: center;
            color: var(--muted-foreground);
            font-size: 0.875rem;
            margin-top: 1rem;
        }

        .hero-note {
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 0.5rem;
        }

        .faq-section {
            padding: 5rem 0;
            background: var(--muted);
        }

        .faq-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
            gap: 2rem;
            max-width: 72rem;
            margin: 0 auto;
        }

        .faq-item {
            background: var(--card);
            border-radius: var(--radius);
            padding: 2rem;
            box-shadow: 0 1px 3px rgba(0, 0, 0, 0.1);
            border: 1px solid var(--border);
        }

        .faq-item h3 {
            font-size: 1.125rem;
            font-weight: 600;
            color: var(--foreground);
            margin-bottom: 1rem;
        }

        .faq-item p {
            color: var(--muted-foreground);
            line-height: 1.6;
        }

        @media (max-width: 768px) {
            .hero-note {
                flex-direction: column;
                gap: 0.25rem;
            }
        }
    </style>
</body>
</html>
