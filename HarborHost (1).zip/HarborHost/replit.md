# Overview

This is a full-stack web application built with React, Express, and TypeScript following a modern monorepo structure. The project appears to be named "rest-express" and is set up as a complete development environment with both frontend and backend components. The application uses a PostgreSQL database with Drizzle ORM for data management and includes comprehensive UI components built with shadcn/ui and Radix UI primitives.

# User Preferences

Preferred communication style: Simple, everyday language.

# System Architecture

## Frontend Architecture
The frontend is built using React with TypeScript and follows a component-based architecture:

- **Build System**: Vite for fast development and optimized production builds
- **Routing**: Wouter for lightweight client-side routing
- **State Management**: TanStack Query (React Query) for server state management
- **UI Framework**: shadcn/ui components built on Radix UI primitives
- **Styling**: Tailwind CSS with CSS custom properties for theming
- **Form Handling**: React Hook Form with Zod validation resolvers

The frontend structure separates concerns with dedicated directories for components, hooks, pages, and utilities. The UI components are highly modular and follow design system principles with consistent theming.

## Backend Architecture
The backend uses Express.js with TypeScript in an ESM setup:

- **Server Framework**: Express.js with custom middleware for logging and error handling
- **Development Setup**: Custom Vite integration for hot module replacement in development
- **API Structure**: RESTful API with routes prefixed under `/api`
- **Storage Layer**: Abstracted storage interface with in-memory implementation for development

The server architecture separates routing logic from storage operations, making it easy to swap storage implementations.

## Data Storage
The application uses Drizzle ORM for database operations:

- **Database**: PostgreSQL (configured for Neon Database)
- **ORM**: Drizzle ORM with TypeScript support
- **Schema Management**: Shared schema definitions between frontend and backend
- **Migrations**: Drizzle Kit for database migrations
- **Development Storage**: In-memory storage implementation for rapid prototyping

The storage layer is abstracted through interfaces, allowing for easy testing and development without requiring a full database setup.

## Authentication and Security
The application includes session-based authentication infrastructure:

- **Session Management**: PostgreSQL session store using connect-pg-simple
- **Session Security**: Configured for secure cookie handling
- **User Management**: Basic user schema with username/password authentication
- **Input Validation**: Zod schemas for type-safe data validation

## Development Experience
The project is optimized for modern development workflows:

- **Hot Reload**: Vite development server with HMR
- **Type Safety**: Full TypeScript coverage across frontend and backend
- **Path Aliases**: Configured import aliases for clean code organization
- **Error Handling**: Runtime error overlays and comprehensive error boundaries
- **Code Quality**: ESLint and TypeScript strict mode for code quality

The build process creates optimized bundles for both client and server code, with the server being bundled using esbuild for production deployment.

# External Dependencies

## Core Framework Dependencies
- **@neondatabase/serverless**: Neon Database PostgreSQL driver for serverless environments
- **drizzle-orm**: Modern TypeScript ORM for SQL databases
- **express**: Web application framework for Node.js
- **react**: Frontend UI library
- **vite**: Build tool and development server

## UI and Styling
- **@radix-ui/***: Comprehensive set of accessible UI primitives (accordion, dialog, dropdown, form controls, etc.)
- **tailwindcss**: Utility-first CSS framework
- **class-variance-authority**: Utility for creating variant-based component APIs
- **lucide-react**: Icon library with React components

## Development and Build Tools
- **typescript**: Type system for JavaScript
- **@vitejs/plugin-react**: Vite plugin for React support
- **esbuild**: Fast JavaScript bundler for server-side code
- **tsx**: TypeScript execution environment for development

## Form and Data Management
- **@tanstack/react-query**: Server state management and caching
- **react-hook-form**: Performant forms with easy validation
- **@hookform/resolvers**: Validation resolvers for React Hook Form
- **zod**: TypeScript-first schema validation
- **date-fns**: Date utility library

## Routing and Navigation
- **wouter**: Minimalist routing library for React

## Database and Session Management
- **connect-pg-simple**: PostgreSQL session store for Express sessions
- **drizzle-kit**: CLI and utilities for Drizzle ORM

## Additional UI Components
- **cmdk**: Command palette component
- **embla-carousel-react**: Carousel component library
- **vaul**: Drawer component library
- **input-otp**: OTP input component

The application also includes Stripe payment processing infrastructure, as evidenced by the payment-related JavaScript files and Stripe vendor directory, though the main package.json doesn't show Stripe as a direct dependency.