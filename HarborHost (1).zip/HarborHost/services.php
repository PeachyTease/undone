<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Services - HopeHarbor</title>
    <meta name="description" content="Comprehensive mental health services including telehealth sessions, support groups, wellness tools, and 24/7 crisis support.">
    
    <!-- Fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
    
    <!-- Styles -->
    <link rel="stylesheet" href="assets/css/styles.css">
</head>

<body>
    <?php include 'includes/header.php'; ?>

    <!-- Hero Section -->
    <section class="hero-section">
        <div class="container">
            <div class="hero-content" style="text-align: center; max-width: 48rem; margin: 0 auto;">
                <h1 class="hero-title" data-testid="text-services-hero-title">
                    Comprehensive Mental Health Services
                </h1>
                <p class="hero-description" data-testid="text-services-hero-description">
                    Access a full range of evidence-based mental health services designed to support your unique journey toward wellness and recovery.
                </p>
                <div class="hero-actions">
                    <button class="btn btn-white" onclick="showAuthModal('signup')" data-testid="button-get-started">
                        Get Started Today
                    </button>
                    <button class="btn btn-outline-white" onclick="scrollToSection('services-detail')" data-testid="button-explore-services">
                        Explore Services
                    </button>
                </div>
            </div>
        </div>
    </section>

    <!-- Detailed Services Section -->
    <section id="services-detail" class="services-section">
        <div class="container">
            <!-- Telehealth Sessions -->
            <div class="service-detail" data-testid="section-telehealth">
                <div class="service-detail-grid">
                    <div class="service-detail-content">
                        <div class="service-icon service-icon-large">
                            <i class="fas fa-video"></i>
                        </div>
                        <h2 class="service-detail-title">Telehealth Sessions</h2>
                        <p class="service-detail-description">
                            Connect with licensed therapists and counselors through secure, HIPAA-compliant video sessions. 
                            Our platform makes it easy to access professional mental health care from anywhere.
                        </p>
                        <ul class="service-features">
                            <li><i class="fas fa-check"></i> Licensed mental health professionals</li>
                            <li><i class="fas fa-check"></i> Secure, encrypted video sessions</li>
                            <li><i class="fas fa-check"></i> Flexible scheduling options</li>
                            <li><i class="fas fa-check"></i> Session notes and progress tracking</li>
                            <li><i class="fas fa-check"></i> Multiple therapy modalities available</li>
                        </ul>
                        <button class="btn btn-primary" onclick="selectPlan('premium', 79)" data-testid="button-start-telehealth">
                            Start Telehealth Sessions
                        </button>
                    </div>
                    <div class="service-detail-image">
                        <img src="https://images.unsplash.com/photo-1559757148-5c350d0d3c56?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&h=400" alt="Telehealth session" data-testid="img-telehealth" />
                    </div>
                </div>
            </div>

            <!-- Support Groups -->
            <div class="service-detail" data-testid="section-support-groups">
                <div class="service-detail-grid service-detail-reverse">
                    <div class="service-detail-image">
                        <img src="https://images.unsplash.com/photo-1529156069898-49953e39b3ac?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&h=400" alt="Support group session" data-testid="img-support-groups" />
                    </div>
                    <div class="service-detail-content">
                        <div class="service-icon service-icon-large service-icon-cyan">
                            <i class="fas fa-users"></i>
                        </div>
                        <h2 class="service-detail-title">Support Groups</h2>
                        <p class="service-detail-description">
                            Join peer-led support groups facilitated by mental health professionals. Connect with others 
                            who understand your challenges and share in your journey toward healing.
                        </p>
                        <ul class="service-features">
                            <li><i class="fas fa-check"></i> Peer support and understanding</li>
                            <li><i class="fas fa-check"></i> Professional facilitation</li>
                            <li><i class="fas fa-check"></i> Various topics and conditions</li>
                            <li><i class="fas fa-check"></i> Safe, confidential environment</li>
                            <li><i class="fas fa-check"></i> Regular meeting schedules</li>
                        </ul>
                        <button class="btn btn-primary" onclick="selectPlan('basic', 29)" data-testid="button-join-groups">
                            Join Support Groups
                        </button>
                    </div>
                </div>
            </div>

            <!-- Wellness Tools -->
            <div class="service-detail" data-testid="section-wellness-tools">
                <div class="service-detail-grid">
                    <div class="service-detail-content">
                        <div class="service-icon service-icon-large service-icon-green">
                            <i class="fas fa-brain"></i>
                        </div>
                        <h2 class="service-detail-title">Wellness Tools</h2>
                        <p class="service-detail-description">
                            Access a comprehensive suite of mental health tools including mood tracking, guided meditations, 
                            coping strategies, and personalized wellness plans.
                        </p>
                        <ul class="service-features">
                            <li><i class="fas fa-check"></i> Daily mood tracking</li>
                            <li><i class="fas fa-check"></i> Guided meditation library</li>
                            <li><i class="fas fa-check"></i> Personalized coping strategies</li>
                            <li><i class="fas fa-check"></i> Progress monitoring</li>
                            <li><i class="fas fa-check"></i> Goal setting and tracking</li>
                        </ul>
                        <button class="btn btn-primary" onclick="selectPlan('basic', 29)" data-testid="button-access-tools">
                            Access Wellness Tools
                        </button>
                    </div>
                    <div class="service-detail-image">
                        <img src="https://images.unsplash.com/photo-1506905925346-21bda4d32df4?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&h=400" alt="Wellness and meditation" data-testid="img-wellness-tools" />
                    </div>
                </div>
            </div>

            <!-- Crisis Support -->
            <div class="service-detail crisis-support" data-testid="section-crisis-support">
                <div class="crisis-support-content">
                    <div class="service-icon service-icon-large service-icon-purple">
                        <i class="fas fa-phone"></i>
                    </div>
                    <h2 class="service-detail-title">24/7 Crisis Support</h2>
                    <p class="service-detail-description">
                        Immediate access to crisis counselors when you need support the most. Our trained professionals 
                        are available around the clock to provide assistance during mental health emergencies.
                    </p>
                    <div class="crisis-features">
                        <div class="crisis-feature">
                            <i class="fas fa-clock"></i>
                            <h3>Available 24/7</h3>
                            <p>Round-the-clock access to crisis support</p>
                        </div>
                        <div class="crisis-feature">
                            <i class="fas fa-user-md"></i>
                            <h3>Trained Professionals</h3>
                            <p>Licensed crisis counselors and mental health experts</p>
                        </div>
                        <div class="crisis-feature">
                            <i class="fas fa-shield-alt"></i>
                            <h3>Confidential & Safe</h3>
                            <p>Private, secure support when you need it most</p>
                        </div>
                    </div>
                    <div class="crisis-actions">
                        <button class="btn btn-primary btn-large" onclick="accessCrisisSupport()" data-testid="button-crisis-help">
                            <i class="fas fa-phone"></i> Get Help Now
                        </button>
                        <button class="btn btn-secondary" onclick="selectPlan('premium', 79)" data-testid="button-crisis-plan">
                            Include in Plan
                        </button>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Getting Started Section -->
    <section class="cta-section">
        <div class="container">
            <div class="cta-content">
                <h2 class="cta-title" data-testid="text-cta-services-title">Ready to Begin Your Mental Health Journey?</h2>
                <p class="cta-description" data-testid="text-cta-services-description">
                    Choose the plan that's right for you and start accessing professional mental health support today.
                </p>
                <div class="cta-actions">
                    <button class="btn btn-white" onclick="window.location.href='pricing.php'" data-testid="button-view-pricing">
                        View Pricing Plans
                    </button>
                    <button class="btn btn-outline-white" onclick="showContactModal()" data-testid="button-schedule-consultation">
                        Schedule Consultation
                    </button>
                </div>
                <p class="cta-note" data-testid="text-cta-services-note">Free consultation available • 7-day trial on all plans</p>
            </div>
        </div>
    </section>

    <?php include 'includes/footer.php'; ?>

    <!-- Scripts -->
    <script src="assets/js/main.js"></script>
    <script src="assets/js/auth.js"></script>

    <style>
        .service-detail {
            margin: 5rem 0;
        }

        .service-detail-grid {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 4rem;
            align-items: center;
        }

        .service-detail-reverse {
            direction: rtl;
        }

        .service-detail-reverse > * {
            direction: ltr;
        }

        .service-icon-large {
            width: 4rem;
            height: 4rem;
            margin-bottom: 2rem;
        }

        .service-detail-title {
            font-size: 2rem;
            font-weight: 700;
            color: var(--foreground);
            margin-bottom: 1.5rem;
        }

        .service-detail-description {
            font-size: 1.125rem;
            color: var(--muted-foreground);
            line-height: 1.6;
            margin-bottom: 2rem;
        }

        .service-features {
            list-style: none;
            margin-bottom: 2rem;
        }

        .service-features li {
            display: flex;
            align-items: center;
            gap: 0.75rem;
            margin-bottom: 1rem;
            color: var(--foreground);
        }

        .service-features i {
            color: #10b981;
        }

        .service-detail-image img {
            width: 100%;
            height: auto;
            border-radius: 1rem;
            box-shadow: 0 10px 25px rgba(0, 0, 0, 0.1);
        }

        .crisis-support {
            background: linear-gradient(135deg, hsl(262, 83%, 95%) 0%, hsl(221.2, 83.2%, 95%) 100%);
            border-radius: 2rem;
            padding: 4rem 2rem;
        }

        .crisis-support-content {
            text-align: center;
            max-width: 48rem;
            margin: 0 auto;
        }

        .crisis-features {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 2rem;
            margin: 3rem 0;
        }

        .crisis-feature {
            text-align: center;
        }

        .crisis-feature i {
            font-size: 2rem;
            color: var(--primary);
            margin-bottom: 1rem;
        }

        .crisis-feature h3 {
            font-size: 1.125rem;
            font-weight: 600;
            color: var(--foreground);
            margin-bottom: 0.5rem;
        }

        .crisis-feature p {
            color: var(--muted-foreground);
        }

        .crisis-actions {
            display: flex;
            gap: 1rem;
            justify-content: center;
            flex-wrap: wrap;
        }

        .btn-large {
            padding: 1rem 2rem;
            font-size: 1.125rem;
        }

        @media (max-width: 768px) {
            .service-detail-grid {
                grid-template-columns: 1fr;
                gap: 2rem;
            }

            .service-detail-reverse {
                direction: ltr;
            }

            .crisis-support {
                padding: 2rem 1rem;
            }

            .crisis-actions {
                flex-direction: column;
                align-items: center;
            }
        }
    </style>
</body>
</html>
