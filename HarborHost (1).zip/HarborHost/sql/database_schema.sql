-- HopeHarbor Database Schema for MySQL (GoDaddy Compatible)

-- Create database (you may need to create this through GoDaddy's control panel)
-- CREATE DATABASE hopeharbor_db CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

-- Use the database
-- USE hopeharbor_db;

-- Users table
CREATE TABLE IF NOT EXISTS users (
    id VARCHAR(36) NOT NULL PRIMARY KEY DEFAULT (UUID()),
    first_name VARCHAR(100) NOT NULL,
    last_name VARCHAR(100) NOT NULL,
    email VARCHAR(255) NOT NULL UNIQUE,
    password VARCHAR(255) NOT NULL,
    subscription_plan ENUM('basic', 'premium', 'professional') NULL,
    subscription_status ENUM('active', 'trialing', 'past_due', 'canceled', 'unpaid') NULL,
    stripe_customer_id VARCHAR(255) NULL,
    stripe_subscription_id VARCHAR(255) NULL,
    trial_ends_at DATETIME NULL,
    last_payment_at DATETIME NULL,
    canceled_at DATETIME NULL,
    is_active BOOLEAN NOT NULL DEFAULT TRUE,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    last_login DATETIME NULL,
    
    INDEX idx_email (email),
    INDEX idx_stripe_customer (stripe_customer_id),
    INDEX idx_stripe_subscription (stripe_subscription_id),
    INDEX idx_subscription_status (subscription_status),
    INDEX idx_created_at (created_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Therapists table
CREATE TABLE IF NOT EXISTS therapists (
    id VARCHAR(36) NOT NULL PRIMARY KEY DEFAULT (UUID()),
    first_name VARCHAR(100) NOT NULL,
    last_name VARCHAR(100) NOT NULL,
    email VARCHAR(255) NOT NULL UNIQUE,
    license_number VARCHAR(100) NOT NULL,
    license_state VARCHAR(50) NOT NULL,
    specializations JSON NULL,
    bio TEXT NULL,
    profile_image_url VARCHAR(500) NULL,
    is_active BOOLEAN NOT NULL DEFAULT TRUE,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    
    INDEX idx_email (email),
    INDEX idx_license (license_number),
    INDEX idx_specializations (specializations(100))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Therapy sessions table
CREATE TABLE IF NOT EXISTS therapy_sessions (
    id VARCHAR(36) NOT NULL PRIMARY KEY DEFAULT (UUID()),
    user_id VARCHAR(36) NOT NULL,
    therapist_id VARCHAR(36) NOT NULL,
    scheduled_at DATETIME NOT NULL,
    duration_minutes INT NOT NULL DEFAULT 50,
    status ENUM('scheduled', 'in_progress', 'completed', 'canceled', 'no_show') NOT NULL DEFAULT 'scheduled',
    session_notes TEXT NULL,
    session_recording_url VARCHAR(500) NULL,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (therapist_id) REFERENCES therapists(id) ON DELETE CASCADE,
    INDEX idx_user_sessions (user_id, scheduled_at),
    INDEX idx_therapist_sessions (therapist_id, scheduled_at),
    INDEX idx_status (status)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Support groups table
CREATE TABLE IF NOT EXISTS support_groups (
    id VARCHAR(36) NOT NULL PRIMARY KEY DEFAULT (UUID()),
    name VARCHAR(200) NOT NULL,
    description TEXT NULL,
    category VARCHAR(100) NOT NULL,
    max_participants INT NOT NULL DEFAULT 12,
    facilitator_id VARCHAR(36) NULL,
    meeting_schedule JSON NULL, -- Days/times when group meets
    is_active BOOLEAN NOT NULL DEFAULT TRUE,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    
    FOREIGN KEY (facilitator_id) REFERENCES therapists(id) ON DELETE SET NULL,
    INDEX idx_category (category),
    INDEX idx_active (is_active)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Group memberships table
CREATE TABLE IF NOT EXISTS group_memberships (
    id VARCHAR(36) NOT NULL PRIMARY KEY DEFAULT (UUID()),
    user_id VARCHAR(36) NOT NULL,
    group_id VARCHAR(36) NOT NULL,
    joined_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    left_at DATETIME NULL,
    is_active BOOLEAN NOT NULL DEFAULT TRUE,
    
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (group_id) REFERENCES support_groups(id) ON DELETE CASCADE,
    UNIQUE KEY unique_active_membership (user_id, group_id, is_active),
    INDEX idx_user_groups (user_id),
    INDEX idx_group_members (group_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Group sessions table
CREATE TABLE IF NOT EXISTS group_sessions (
    id VARCHAR(36) NOT NULL PRIMARY KEY DEFAULT (UUID()),
    group_id VARCHAR(36) NOT NULL,
    facilitator_id VARCHAR(36) NULL,
    scheduled_at DATETIME NOT NULL,
    duration_minutes INT NOT NULL DEFAULT 60,
    topic VARCHAR(200) NULL,
    status ENUM('scheduled', 'in_progress', 'completed', 'canceled') NOT NULL DEFAULT 'scheduled',
    session_notes TEXT NULL,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    
    FOREIGN KEY (group_id) REFERENCES support_groups(id) ON DELETE CASCADE,
    FOREIGN KEY (facilitator_id) REFERENCES therapists(id) ON DELETE SET NULL,
    INDEX idx_group_schedule (group_id, scheduled_at),
    INDEX idx_status (status)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Mood tracking table
CREATE TABLE IF NOT EXISTS mood_entries (
    id VARCHAR(36) NOT NULL PRIMARY KEY DEFAULT (UUID()),
    user_id VARCHAR(36) NOT NULL,
    mood_score INT NOT NULL CHECK (mood_score >= 1 AND mood_score <= 10),
    energy_level INT NULL CHECK (energy_level >= 1 AND energy_level <= 10),
    anxiety_level INT NULL CHECK (anxiety_level >= 1 AND anxiety_level <= 10),
    notes TEXT NULL,
    recorded_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    INDEX idx_user_mood (user_id, recorded_at),
    INDEX idx_recorded_date (recorded_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Wellness activities table
CREATE TABLE IF NOT EXISTS wellness_activities (
    id VARCHAR(36) NOT NULL PRIMARY KEY DEFAULT (UUID()),
    name VARCHAR(200) NOT NULL,
    description TEXT NULL,
    category ENUM('meditation', 'breathing', 'journaling', 'exercise', 'relaxation', 'mindfulness') NOT NULL,
    duration_minutes INT NULL,
    instructions TEXT NULL,
    audio_url VARCHAR(500) NULL,
    video_url VARCHAR(500) NULL,
    is_active BOOLEAN NOT NULL DEFAULT TRUE,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    
    INDEX idx_category (category),
    INDEX idx_active (is_active)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- User activity tracking table
CREATE TABLE IF NOT EXISTS user_activity_log (
    id VARCHAR(36) NOT NULL PRIMARY KEY DEFAULT (UUID()),
    user_id VARCHAR(36) NOT NULL,
    activity_type ENUM('session_completed', 'group_attended', 'wellness_activity', 'mood_logged', 'resource_accessed') NOT NULL,
    activity_id VARCHAR(36) NULL, -- References the specific activity
    details JSON NULL,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    INDEX idx_user_activity (user_id, created_at),
    INDEX idx_activity_type (activity_type)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Crisis contacts table
CREATE TABLE IF NOT EXISTS crisis_contacts (
    id VARCHAR(36) NOT NULL PRIMARY KEY DEFAULT (UUID()),
    name VARCHAR(200) NOT NULL,
    phone VARCHAR(50) NOT NULL,
    description TEXT NULL,
    coverage_area VARCHAR(100) NULL, -- Geographic area
    availability VARCHAR(100) NULL, -- Hours available
    is_active BOOLEAN NOT NULL DEFAULT TRUE,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    
    INDEX idx_coverage (coverage_area),
    INDEX idx_active (is_active)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Contact form submissions table
CREATE TABLE IF NOT EXISTS contact_submissions (
    id VARCHAR(36) NOT NULL PRIMARY KEY DEFAULT (UUID()),
    first_name VARCHAR(100) NOT NULL,
    last_name VARCHAR(100) NOT NULL,
    email VARCHAR(255) NOT NULL,
    phone VARCHAR(50) NULL,
    subject VARCHAR(200) NOT NULL,
    message TEXT NOT NULL,
    newsletter_signup BOOLEAN NOT NULL DEFAULT FALSE,
    status ENUM('new', 'in_progress', 'resolved') NOT NULL DEFAULT 'new',
    responded_at DATETIME NULL,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    
    INDEX idx_email (email),
    INDEX idx_status (status),
    INDEX idx_created_at (created_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Consultation requests table
CREATE TABLE IF NOT EXISTS consultation_requests (
    id VARCHAR(36) NOT NULL PRIMARY KEY DEFAULT (UUID()),
    first_name VARCHAR(100) NOT NULL,
    last_name VARCHAR(100) NOT NULL,
    email VARCHAR(255) NOT NULL,
    phone VARCHAR(50) NOT NULL,
    preferred_day ENUM('monday', 'tuesday', 'wednesday', 'thursday', 'friday') NOT NULL,
    preferred_time VARCHAR(20) NOT NULL,
    topics TEXT NULL,
    status ENUM('pending', 'scheduled', 'completed', 'canceled') NOT NULL DEFAULT 'pending',
    scheduled_at DATETIME NULL,
    completed_at DATETIME NULL,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    
    INDEX idx_email (email),
    INDEX idx_status (status),
    INDEX idx_scheduled (scheduled_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Insert sample data for crisis contacts
INSERT INTO crisis_contacts (name, phone, description, coverage_area, availability) VALUES
('National Suicide Prevention Lifeline', '988', '24/7 crisis support for suicidal thoughts', 'United States', '24/7'),
('Crisis Text Line', '741741', 'Text HOME to connect with a crisis counselor', 'United States', '24/7'),
('National Alliance on Mental Illness (NAMI) Helpline', '1-800-950-6264', 'Information and support for mental health concerns', 'United States', 'Mon-Fri 10am-6pm ET'),
('SAMHSA National Helpline', '1-800-662-4357', 'Treatment referral and information service', 'United States', '24/7');

-- Insert sample wellness activities
INSERT INTO wellness_activities (name, description, category, duration_minutes, instructions) VALUES
('5-Minute Breathing Exercise', 'Simple breathing technique to reduce anxiety and stress', 'breathing', 5, 'Sit comfortably and breathe in for 4 counts, hold for 4 counts, breathe out for 6 counts. Repeat for 5 minutes.'),
('Mindful Body Scan', 'Progressive relaxation focusing on different body parts', 'meditation', 15, 'Lie down comfortably and slowly focus on each part of your body from toes to head, noticing any tension and releasing it.'),
('Gratitude Journaling', 'Daily practice of writing down things you''re grateful for', 'journaling', 10, 'Write down 3 things you''re grateful for today and why they matter to you.'),
('Progressive Muscle Relaxation', 'Technique to reduce physical tension and stress', 'relaxation', 20, 'Tense and then relax each muscle group in your body, starting from your feet and working up to your head.');
