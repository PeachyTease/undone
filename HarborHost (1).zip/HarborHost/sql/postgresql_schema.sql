-- HopeHarbor Database Schema for PostgreSQL (Testing)

-- Enable UUID extension
CREATE EXTENSION IF NOT EXISTS pgcrypto;

-- Users table
CREATE TABLE IF NOT EXISTS users (
    id VARCHAR(36) NOT NULL PRIMARY KEY DEFAULT gen_random_uuid()::text,
    first_name VARCHAR(100) NOT NULL,
    last_name VARCHAR(100) NOT NULL,
    email VARCHAR(255) NOT NULL UNIQUE,
    password VARCHAR(255) NOT NULL,
    subscription_plan VARCHAR(20) CHECK (subscription_plan IN ('basic', 'premium', 'professional')),
    subscription_status VARCHAR(20) CHECK (subscription_status IN ('active', 'trialing', 'past_due', 'canceled', 'unpaid')),
    stripe_customer_id VARCHAR(255),
    stripe_subscription_id VARCHAR(255),
    trial_ends_at TIMESTAMP,
    last_payment_at TIMESTAMP,
    canceled_at TIMESTAMP,
    is_active BOOLEAN NOT NULL DEFAULT TRUE,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    last_login TIMESTAMP
);

-- Create indexes for users table
CREATE INDEX IF NOT EXISTS idx_users_email ON users(email);
CREATE INDEX IF NOT EXISTS idx_users_stripe_customer ON users(stripe_customer_id);
CREATE INDEX IF NOT EXISTS idx_users_stripe_subscription ON users(stripe_subscription_id);
CREATE INDEX IF NOT EXISTS idx_users_subscription_status ON users(subscription_status);
CREATE INDEX IF NOT EXISTS idx_users_created_at ON users(created_at);

-- Therapists table
CREATE TABLE IF NOT EXISTS therapists (
    id VARCHAR(36) NOT NULL PRIMARY KEY DEFAULT gen_random_uuid()::text,
    first_name VARCHAR(100) NOT NULL,
    last_name VARCHAR(100) NOT NULL,
    email VARCHAR(255) NOT NULL UNIQUE,
    license_number VARCHAR(100) NOT NULL,
    license_state VARCHAR(50) NOT NULL,
    specializations JSONB,
    bio TEXT,
    profile_image_url VARCHAR(500),
    is_active BOOLEAN NOT NULL DEFAULT TRUE,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
);

-- Therapy sessions table
CREATE TABLE IF NOT EXISTS therapy_sessions (
    id VARCHAR(36) NOT NULL PRIMARY KEY DEFAULT gen_random_uuid()::text,
    user_id VARCHAR(36) NOT NULL,
    therapist_id VARCHAR(36) NOT NULL,
    scheduled_at TIMESTAMP NOT NULL,
    duration_minutes INTEGER NOT NULL DEFAULT 50,
    status VARCHAR(20) NOT NULL DEFAULT 'scheduled' CHECK (status IN ('scheduled', 'in_progress', 'completed', 'canceled', 'no_show')),
    session_notes TEXT,
    session_recording_url VARCHAR(500),
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (therapist_id) REFERENCES therapists(id) ON DELETE CASCADE
);

-- Support groups table
CREATE TABLE IF NOT EXISTS support_groups (
    id VARCHAR(36) NOT NULL PRIMARY KEY DEFAULT gen_random_uuid()::text,
    name VARCHAR(200) NOT NULL,
    description TEXT,
    category VARCHAR(100) NOT NULL,
    max_participants INTEGER NOT NULL DEFAULT 12,
    facilitator_id VARCHAR(36),
    meeting_schedule JSONB,
    is_active BOOLEAN NOT NULL DEFAULT TRUE,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    
    FOREIGN KEY (facilitator_id) REFERENCES therapists(id) ON DELETE SET NULL
);

-- Group memberships table
CREATE TABLE IF NOT EXISTS group_memberships (
    id VARCHAR(36) NOT NULL PRIMARY KEY DEFAULT gen_random_uuid()::text,
    user_id VARCHAR(36) NOT NULL,
    group_id VARCHAR(36) NOT NULL,
    joined_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    left_at TIMESTAMP,
    is_active BOOLEAN NOT NULL DEFAULT TRUE,
    
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (group_id) REFERENCES support_groups(id) ON DELETE CASCADE
);

-- Contact form submissions table
CREATE TABLE IF NOT EXISTS contact_submissions (
    id VARCHAR(36) NOT NULL PRIMARY KEY DEFAULT gen_random_uuid()::text,
    first_name VARCHAR(100) NOT NULL,
    last_name VARCHAR(100) NOT NULL,
    email VARCHAR(255) NOT NULL,
    phone VARCHAR(50),
    subject VARCHAR(200) NOT NULL,
    message TEXT NOT NULL,
    newsletter_signup BOOLEAN NOT NULL DEFAULT FALSE,
    status VARCHAR(20) NOT NULL DEFAULT 'new' CHECK (status IN ('new', 'in_progress', 'resolved')),
    responded_at TIMESTAMP,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
);

-- Group sessions table
CREATE TABLE IF NOT EXISTS group_sessions (
    id VARCHAR(36) NOT NULL PRIMARY KEY DEFAULT gen_random_uuid()::text,
    group_id VARCHAR(36) NOT NULL,
    facilitator_id VARCHAR(36),
    scheduled_at TIMESTAMP NOT NULL,
    duration_minutes INTEGER NOT NULL DEFAULT 60,
    topic VARCHAR(200),
    status VARCHAR(20) NOT NULL DEFAULT 'scheduled' CHECK (status IN ('scheduled', 'in_progress', 'completed', 'canceled')),
    session_notes TEXT,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    
    FOREIGN KEY (group_id) REFERENCES support_groups(id) ON DELETE CASCADE,
    FOREIGN KEY (facilitator_id) REFERENCES therapists(id) ON DELETE SET NULL
);

-- Mood tracking table
CREATE TABLE IF NOT EXISTS mood_entries (
    id VARCHAR(36) NOT NULL PRIMARY KEY DEFAULT gen_random_uuid()::text,
    user_id VARCHAR(36) NOT NULL,
    mood_score INTEGER NOT NULL CHECK (mood_score >= 1 AND mood_score <= 10),
    energy_level INTEGER CHECK (energy_level >= 1 AND energy_level <= 10),
    anxiety_level INTEGER CHECK (anxiety_level >= 1 AND anxiety_level <= 10),
    notes TEXT,
    recorded_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

-- Wellness activities table
CREATE TABLE IF NOT EXISTS wellness_activities (
    id VARCHAR(36) NOT NULL PRIMARY KEY DEFAULT gen_random_uuid()::text,
    name VARCHAR(200) NOT NULL,
    description TEXT,
    category VARCHAR(20) NOT NULL CHECK (category IN ('meditation', 'breathing', 'journaling', 'exercise', 'relaxation', 'mindfulness')),
    duration_minutes INTEGER,
    instructions TEXT,
    audio_url VARCHAR(500),
    video_url VARCHAR(500),
    is_active BOOLEAN NOT NULL DEFAULT TRUE,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
);

-- User activity tracking table
CREATE TABLE IF NOT EXISTS user_activity_log (
    id VARCHAR(36) NOT NULL PRIMARY KEY DEFAULT gen_random_uuid()::text,
    user_id VARCHAR(36) NOT NULL,
    activity_type VARCHAR(30) NOT NULL CHECK (activity_type IN ('session_completed', 'group_attended', 'wellness_activity', 'mood_logged', 'resource_accessed')),
    activity_id VARCHAR(36),
    details JSONB,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

-- Crisis contacts table
CREATE TABLE IF NOT EXISTS crisis_contacts (
    id VARCHAR(36) NOT NULL PRIMARY KEY DEFAULT gen_random_uuid()::text,
    name VARCHAR(200) NOT NULL,
    phone VARCHAR(50) NOT NULL,
    description TEXT,
    coverage_area VARCHAR(100),
    availability VARCHAR(100),
    is_active BOOLEAN NOT NULL DEFAULT TRUE,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
);

-- Consultation requests table
CREATE TABLE IF NOT EXISTS consultation_requests (
    id VARCHAR(36) NOT NULL PRIMARY KEY DEFAULT gen_random_uuid()::text,
    first_name VARCHAR(100) NOT NULL,
    last_name VARCHAR(100) NOT NULL,
    email VARCHAR(255) NOT NULL,
    phone VARCHAR(50) NOT NULL,
    preferred_day VARCHAR(20) NOT NULL CHECK (preferred_day IN ('monday', 'tuesday', 'wednesday', 'thursday', 'friday')),
    preferred_time VARCHAR(20) NOT NULL,
    topics TEXT,
    status VARCHAR(20) NOT NULL DEFAULT 'pending' CHECK (status IN ('pending', 'scheduled', 'completed', 'canceled')),
    scheduled_at TIMESTAMP,
    completed_at TIMESTAMP,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
);

-- Insert sample data for crisis contacts
INSERT INTO crisis_contacts (name, phone, description, coverage_area, availability) VALUES
('National Suicide Prevention Lifeline', '988', '24/7 crisis support for suicidal thoughts', 'United States', '24/7'),
('Crisis Text Line', '741741', 'Text HOME to connect with a crisis counselor', 'United States', '24/7'),
('National Alliance on Mental Illness (NAMI) Helpline', '1-800-950-6264', 'Information and support for mental health concerns', 'United States', 'Mon-Fri 10am-6pm ET'),
('SAMHSA National Helpline', '1-800-662-4357', 'Treatment referral and information service', 'United States', '24/7')
ON CONFLICT DO NOTHING;

-- Insert sample wellness activities
INSERT INTO wellness_activities (name, description, category, duration_minutes, instructions) VALUES
('5-Minute Breathing Exercise', 'Simple breathing technique to reduce anxiety and stress', 'breathing', 5, 'Sit comfortably and breathe in for 4 counts, hold for 4 counts, breathe out for 6 counts. Repeat for 5 minutes.'),
('Mindful Body Scan', 'Progressive relaxation focusing on different body parts', 'meditation', 15, 'Lie down comfortably and slowly focus on each part of your body from toes to head, noticing any tension and releasing it.'),
('Gratitude Journaling', 'Daily practice of writing down things you''re grateful for', 'journaling', 10, 'Write down 3 things you''re grateful for today and why they matter to you.'),
('Progressive Muscle Relaxation', 'Technique to reduce physical tension and stress', 'relaxation', 20, 'Tense and then relax each muscle group in your body, starting from your feet and working up to your head.')
ON CONFLICT DO NOTHING;

-- Update triggers for updated_at timestamps
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
    NEW.updated_at = CURRENT_TIMESTAMP;
    RETURN NEW;
END;
$$ language 'plpgsql';

CREATE OR REPLACE TRIGGER update_users_updated_at BEFORE UPDATE ON users FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
CREATE OR REPLACE TRIGGER update_therapists_updated_at BEFORE UPDATE ON therapists FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
CREATE OR REPLACE TRIGGER update_therapy_sessions_updated_at BEFORE UPDATE ON therapy_sessions FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
CREATE OR REPLACE TRIGGER update_support_groups_updated_at BEFORE UPDATE ON support_groups FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
CREATE OR REPLACE TRIGGER update_group_sessions_updated_at BEFORE UPDATE ON group_sessions FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();